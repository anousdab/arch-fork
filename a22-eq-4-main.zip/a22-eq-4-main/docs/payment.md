# Payment

### Pay extra fees

`POST` http://localhost:8080/api/payment/pay-extra-fees

Cet appel permet de payer les extra fees.

#### Entrée

##### _header_

```java

{

    "idul": string Format: idul

}

```

#### Sortie

##### Code de status: 200 OK


#### Sortie d'erreur

##### Code de status: 404 Not Found

###### Lorsque l'idul entree n'est pas lie a un compte

```json

{

  "error": {

    "code": "404",

    "message": "Idul does not exist"

  }

}

```

### Set Automatic payment

`POST` http://localhost:8080/api/payment/set-automatic-payment

Cet appel permet d'activer le paiement automatique.

#### Entrée

##### _header_

```java

{

    "idul": string Format: idul

}

```

#### Sortie

##### Code de status: 200 OK


#### Sortie d'erreur

##### Code de status: 404 Not Found

###### Lorsque l'idul entree n'est pas lie a un compte

```json

{

  "error": {

    "code": "404",

    "message": "Idul does not exist"

  }

}

```


### Pay debt

`POST` http://localhost:8080/api/payment/pay-debt

Cet appel permet de payer les dettes accumulees.

#### Entrée

##### _header_

```java

{

    "idul": string Format: idul

}

```

#### Sortie

##### Code de status: 200 OK


#### Sortie d'erreur

##### Code de status: 404 Not Found

###### Lorsque l'idul entree n'est pas lie a un compte

```json

{

  "error": {

    "code": "404",

    "message": "Idul does not exist"

  }

}

```


### Save credit card

`POST` http://localhost:8080/api/payment/save-credit-card

Cet appel permet de sauvegarder la carte de credit.

#### Entrée

##### _header_

```java

{

    "idul": string Format: idul

}

```

##### _body_

```java

{

        {

        "creditCardNumber" : string,

        "expirationMonth": int Format: MM,

        "expirationYear": int Format: YYYY,

        "ccv" : int

        }

}

```

#### Sortie d'erreur

##### Code de status: 404 Not Found

###### Lorsque les informations de carte credit sont incorrects

```json

{

  "error": {

    "code": "400",

    "message": "One or more of your subscription parameter is wrong, please try again!"

  }

}

```




