package ca.ulaval.glo4003.sulvlo.e2e.helpers;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.util.List;
import java.util.Map;

public class TravelResourceE2ETestHelper extends BaseE2ETestHelper{

  private static final String TRAVEL_PATH = "api/travel";
  private static final String GET_ALL_TRAVELS_PATH = "/all";
  private static final String GET_TRAVEL_HISTORY_SUMMARY_PATH = "/summary";

  private static final String MONTH_HEADER_PARAMETER = "month";
  private static final String USER_ID_HEADER_PARAMETER = "userId";
  private static final String TRAVEL_ID_RESPONSE_PARAMETER = "Id";


  public Response getAllTravels() {
    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .when()
        .get(TRAVEL_PATH + GET_ALL_TRAVELS_PATH)
        .then()
        .extract()
        .response();
  }

  public Response getAllTravelsByMonth(String userId, String monthChosen) {
    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .header(USER_ID_HEADER_PARAMETER, userId)
        .header(MONTH_HEADER_PARAMETER, monthChosen)
        .when()
        .get(TRAVEL_PATH)
        .then()
        .extract()
        .response();
  }

  public Response getAllTravelsById(String travelId) {
    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .when()
        .get(TRAVEL_PATH + "/" + travelId)
        .then()
        .extract()
        .response();
  }

  public Response getTravelHistorySummary(String userId) {
    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .header(USER_ID_HEADER_PARAMETER, userId)
        .when()
        .get(TRAVEL_PATH + GET_TRAVEL_HISTORY_SUMMARY_PATH)
        .then()
        .extract()
        .response();
  }

  public String getFirstTravelId(List<Map<String, Object>> listOfAllTravels) {
    String arbitraryTravelId = listOfAllTravels.get(0).get(TRAVEL_ID_RESPONSE_PARAMETER).toString();
    return arbitraryTravelId;
  }

}
