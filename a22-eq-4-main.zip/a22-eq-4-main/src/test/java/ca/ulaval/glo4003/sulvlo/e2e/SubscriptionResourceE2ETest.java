package ca.ulaval.glo4003.sulvlo.e2e;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import ca.ulaval.glo4003.SulvloMain;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.BaseE2ETestHelper;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.SubscriptionResourceE2ETestHelper;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.UserResourceE2ETestHelper;
import io.restassured.RestAssured;
import io.restassured.common.mapper.TypeRef;
import io.restassured.response.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.quartz.SchedulerException;

class SubscriptionResourceE2ETest {

  private static final String[] VALID_SUBSCRIPTION_TYPES = {"Premium", "Base"};
  private static final String INVALID_SUBSCRIPTION_TYPE = "Et Hop";
  private static final int DEFAULT_SUBSCRIPTION_TYPES_SIZE = 2;
  private static final String SUCCESSFULLY_SUSBCRIBED_MSG = "You have been successfully subscribed";
  private static final String INVALID_SUBSCRIPTION_REQUEST_PARAMETER_MSG = "One or more of your subscription parameter is wrong, please try again!";
  private static final String[] REQUEST_RESPONSE_PARAMETER = {"error", "message"};
  private SulvloMain server;
  private Response response;
  private String validActivationToken;
  private String jwtToken;
  private final SubscriptionResourceE2ETestHelper subscriptionResourceE2ETestHelper;
  private final UserResourceE2ETestHelper userResourceE2ETestHelper;


  public SubscriptionResourceE2ETest() {
    this.subscriptionResourceE2ETestHelper = new SubscriptionResourceE2ETestHelper();
    this.userResourceE2ETestHelper = new UserResourceE2ETestHelper();
  }

  @BeforeEach
  public void setUp() throws SchedulerException {
    RestAssured.port = 8080;
    server = new SulvloMain();
    server.run();

    response = userResourceE2ETestHelper.registerUser();

    validActivationToken = response.getHeaders()
        .getValue(BaseE2ETestHelper.REGISTER_USER_HEADER_RESPONSE_PARAMETER);

    jwtToken = userResourceE2ETestHelper.loginUser(BaseE2ETestHelper.USER_EMAIL,
            BaseE2ETestHelper.USER_VALID_PWD).getBody()
        .jsonPath().getString(BaseE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
  }

  @AfterEach
  public void tearDown() {
    server.stopServer();
  }

  @Test
  void givenVerifiedAccountAndValidFormData_whenProceedingToPayment_thenReturnsExpectedStatusCode() {
    userResourceE2ETestHelper.activateAccount(validActivationToken);

    response = subscriptionResourceE2ETestHelper.addSubscription(VALID_SUBSCRIPTION_TYPES[0],
        jwtToken);

    assertEquals(SUCCESSFULLY_SUSBCRIBED_MSG,
        response.getBody().jsonPath().get(REQUEST_RESPONSE_PARAMETER[1]).toString());
    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenVerifiedAccountAndInvalidFormData_whenProceedingToPayment_thenReturnsExpectedStatusCode() {
    userResourceE2ETestHelper.activateAccount(validActivationToken);

    response = subscriptionResourceE2ETestHelper.addSubscription(INVALID_SUBSCRIPTION_TYPE,
        jwtToken);

    LinkedHashMap<String, String> map = response.getBody().jsonPath()
        .get(REQUEST_RESPONSE_PARAMETER[0]);
    String expectedErrorMsg = map.get(REQUEST_RESPONSE_PARAMETER[1]);

    assertEquals(INVALID_SUBSCRIPTION_REQUEST_PARAMETER_MSG, expectedErrorMsg);
    assertEquals(response.statusCode(), Status.BAD_REQUEST.getStatusCode());
  }

  @Test
  void givenUnverifiedAccount_whenProceedingToPayment_thenReturnsExpectedStatusCode() {
    response = subscriptionResourceE2ETestHelper.addSubscription(VALID_SUBSCRIPTION_TYPES[0],
        jwtToken);

    assertEquals(response.statusCode(), Status.UNAUTHORIZED.getStatusCode());
  }

  @Test
  void whenFetchingForSubscriptions_thenReturnsExpectedStatusCode() {
    response = subscriptionResourceE2ETestHelper.getAllSubscriptions();

    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void whenFetchingForSubscriptions_thenReturnsExpectedDefaultSubscriptions() {
    response = subscriptionResourceE2ETestHelper.getAllSubscriptions();

    List<Map<String, Object>> listOfSubscriptions = response.body().as(new TypeRef<>() {
    });
    List listOfTypes = subscriptionResourceE2ETestHelper.convertSubscriptionsToTypes(
        listOfSubscriptions);

    assertTrue(listOfTypes.contains(VALID_SUBSCRIPTION_TYPES[0]));
    assertTrue(listOfTypes.contains(VALID_SUBSCRIPTION_TYPES[1]));
    assertEquals(DEFAULT_SUBSCRIPTION_TYPES_SIZE, listOfSubscriptions.size());
  }
}
