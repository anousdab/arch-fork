package ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription;

import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CCV;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CREDIT_CARD;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CREDIT_CARD_NUMBER;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.DESCRIPTION;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.DURATION;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EMAIL;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EXPIRATION_DAY;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EXPIRATION_MONTH;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.PRICE;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.SEMESTER;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.SUBSCRIPTION_TYPE;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.TYPE;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.BDDMockito.given;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionType;
import ca.ulaval.glo4003.sulvlo.domain.util.semester.SemesterAssembler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class SubscriptionAssemblerTest {

  private static final boolean IMMEDIATE_PAYMENT = true;
  private static final boolean SAVE_PAYMENT = true;
  private static final Subscription SUBSCRIPTION = new Subscription(SUBSCRIPTION_TYPE, EMAIL,
      CREDIT_CARD, SEMESTER, SAVE_PAYMENT, IMMEDIATE_PAYMENT);
  @Mock
  private CreditCardAssembler creditCardAssembler;
  @Mock
  private SemesterAssembler semesterAssembler;
  private SubscriptionAssembler subscriptionAssembler;


  @BeforeEach
  void setup() {
    subscriptionAssembler = new SubscriptionAssembler(creditCardAssembler, semesterAssembler);
  }


  @Test
  void givenSubscriptionTypeAndSubscriptionDto_whenAssemble_thenReturnsSubscription() {

    var subscriptionType = new SubscriptionType(TYPE, PRICE, DESCRIPTION, DURATION);
    var subscriptionDto = new SubscriptionDto(SUBSCRIPTION_TYPE.type(), SEMESTER.toString(), EMAIL,
        CREDIT_CARD_NUMBER, EXPIRATION_MONTH, EXPIRATION_DAY, CCV, SAVE_PAYMENT, IMMEDIATE_PAYMENT);

    given(creditCardAssembler.create(subscriptionDto)).willReturn(CREDIT_CARD);
    given(semesterAssembler.create(subscriptionDto)).willReturn(SEMESTER);

    var subscription = subscriptionAssembler.create(subscriptionType, subscriptionDto);

    assertThat(subscription).isEqualTo(SUBSCRIPTION);
  }


}