package ca.ulaval.glo4003.sulvlo.unitTests.api.station;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.station.StationResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationRequestsCreator;
import ca.ulaval.glo4003.sulvlo.api.station.validation.StationRequestsValidator;
import ca.ulaval.glo4003.sulvlo.domain.station.StationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class StationResourceImplTest {

  @Mock
  private StationService stationService;
  @Mock
  private StationRequestsValidator stationRequestsValidator;
  @Mock
  private SuccessfulResponse successfulResponse;
  @Mock
  private StationRequestsCreator stationRequestsCreator;
  private StationResourceImpl stationResourceImpl;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.openMocks(this);
    stationResourceImpl = new StationResourceImpl(stationService, stationRequestsValidator,
        successfulResponse, stationRequestsCreator);
  }

  @Test
  public void whenListStations_thenStationServiceFindAllStationsShouldBeCalled() {
    stationResourceImpl.listAvailableStations();

    verify(stationService, times(1)).findAllAvailableStations();
  }

}