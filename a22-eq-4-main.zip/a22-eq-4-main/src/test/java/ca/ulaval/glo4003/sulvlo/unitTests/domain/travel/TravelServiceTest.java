package ca.ulaval.glo4003.sulvlo.unitTests.domain.travel;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelDto;
import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelHistorySummaryDTO;
import ca.ulaval.glo4003.sulvlo.domain.travel.Travel;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelRepository;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelService;
import ca.ulaval.glo4003.sulvlo.domain.travel.exception.InvalidUserIdException;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryFactory;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.TravelLogRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TravelServiceTest {

  private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
      "yyyy-MM-dd HH:mm:ss");

  private Travel travel;
  private TravelRepository travelRepository;
  private TravelAssembler travelAssembler;
  private TravelDto travelDto;
  private TravelService travelService;
  private TravelHistoryAssembler travelHistoryAssembler;
  private final String STATION_CODE_BEGIN = "TEST777";
  private final String USER_ID = "1";
  private final String STATION_CODE_END = "TEST2";
  private final Month MONTH_OF_TRAVEL = Month.OCTOBER;
  private final String STARTING_TRAVEL_TIME = "2022-01-10 08:00:00";
  private final String END_TRAVEL_TIME = "2022-01-10 08:40:00";
  private final String MONTH_OF_TRAVEL_IN_STRING = "october";
  private final List<Travel> EMPTY_LIST = new ArrayList<>();
  private TravelHistoryFactory travelHistoryFactory;


  @BeforeEach
  public void setUp() {
    travel = new Travel(UUID.randomUUID(), USER_ID, STATION_CODE_BEGIN,
        LocalDateTime.parse(STARTING_TRAVEL_TIME, formatter),
        LocalDateTime.parse(END_TRAVEL_TIME, formatter),
        STATION_CODE_END, MONTH_OF_TRAVEL);
    travelDto = new TravelDto(travel.travelId().toString(), travel.user_id(),
        travel.stationStartTravel(), travel.startTravelDate().toString(),
        travel.endTravelDate().toString(), travel.stationEndTravel(), travel.month());
    travelHistoryAssembler = new TravelHistoryAssembler();
    travelHistoryFactory = new TravelHistoryFactory();
    travelRepository = mock(TravelLogRepositoryInMemory.class);
    travelAssembler = mock(TravelAssembler.class);
    travelService = new TravelService(travelRepository, travelAssembler, travelHistoryAssembler,
        travelHistoryFactory);
  }

  @Test
  void whenGetAllTravelFromRepository_ThenShouldReturnAArrayOfTravels() {
    List<Travel> listOfTravels = new ArrayList<>();
    listOfTravels.add(travel);
    when(travelRepository.getAllTravels()).thenReturn(listOfTravels);
    when(travelAssembler.create(travel)).thenReturn(travelDto);

    List<TravelDto> travelDtoList = travelService.getAllTravelsFilteredByMonth(
        MONTH_OF_TRAVEL_IN_STRING, USER_ID);

    assertNotNull(travelDtoList);
  }

  @Test
  void givenAStringID_WhenTryingToLocateTheTravel_ThenShouldReturnTravel() throws
      InvalidTravelIdException {
    String id = travelDto.Id();

    when(travelRepository.getTravel(travel.travelId())).thenReturn(travel);
    when(travelAssembler.create(travel)).thenReturn(travelDto);

    TravelDto serviceReturn = travelService.getTravelById(id);

    assertNotNull(serviceReturn);
  }

  @Test
  void whenGetAllTravelsHistory_ThenShouldReturnATravelHistoryDTO() throws Exception {
    List<Travel> listOfTravels = new ArrayList<>();
    listOfTravels.add(travel);
    when(travelRepository.getAllTravels()).thenReturn(listOfTravels);

    TravelHistorySummaryDTO returnService = travelService.getTravelHistorySummary(USER_ID);

    assertNotNull(returnService);
  }

  @Test
  void whenGettingTravelHistoryForUserWhenNoTravelInTheLastMonth_ThenShouldThrowException() {
    when(travelRepository.getAllTravels()).thenReturn(EMPTY_LIST);

    InvalidUserIdException thrown = assertThrows(
        InvalidUserIdException.class, () ->
            travelService.getTravelHistorySummary(USER_ID));

    assertNotNull(thrown);
  }

}
