package ca.ulaval.glo4003.sulvlo.e2e;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.ulaval.glo4003.SulvloMain;
import ca.ulaval.glo4003.sulvlo.auth.jwt.exceptions.InvalidAuthenticationTokenException;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.SubscriptionResourceE2ETestHelper;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.UserResourceE2ETestHelper;
import io.jsonwebtoken.Claims;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import jakarta.ws.rs.core.Response.Status;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.quartz.SchedulerException;

class UserResourceE2ETest {

  private SulvloMain server;
  private Response response;
  private final UserResourceE2ETestHelper userResourceE2ETestHelper;
  private final SubscriptionResourceE2ETestHelper subscriptionResourceE2ETestHelper;

  private static final String ADMIN_USER_NAME = "Anabelle";
  private static final String ADMIN_USER_EMAIL = "ROTHSCHILD@nospam.today";
  private static final String USER_INVALID_PWD = "xXuser777Xx";
  private static final String ADMIN_USER_PWD = "test123";

  private static final String VALID_SUBSCRIPTION_TYPE = "Premium";
  private static final String INVALID_JWT_TOKEN = "trolololo";
  private static final int JWT_VALID_FOR_TIME = 3600;
  private static final String DEFAULT_USER_ROLE = "NORMAL";
  private static final String ADMIN_USER_ROLE = "MANAGER";
  private static final String[] JWT_TOKEN_DETAILS_PARAMETERS = { "name", "email", "role" };
  private static final String INVALID_ACTIVATION_TOKEN = "activationToken777";
  private String validActivationToken;

  public UserResourceE2ETest() {
    this.userResourceE2ETestHelper = new UserResourceE2ETestHelper();
    this.subscriptionResourceE2ETestHelper = new SubscriptionResourceE2ETestHelper();
  }

  @BeforeEach
  public void setUp() throws SchedulerException {
    RestAssured.port = 8080;
    server = new SulvloMain();
    server.run();

    response = userResourceE2ETestHelper.registerUser();
    validActivationToken = response.getHeaders()
        .getValue(userResourceE2ETestHelper.REGISTER_USER_HEADER_RESPONSE_PARAMETER);
  }

  @AfterEach
  public void tearDown() {
    server.stopServer();
  }

  @Test
  void givenValidUserFormData_whenRegistering_thenReturnsExpectedStatusCode() {
    assertEquals(response.statusCode(), Status.CREATED.getStatusCode());
  }

  @Test
  void givenValidUserFormData_whenRegistering_thenUserIdHeaderIsValid() {
    assertNotNull(
        response.getHeader(userResourceE2ETestHelper.REGISTER_USER_HEADER_RESPONSE_PARAMETER));
  }

  @Test
  void givenValidUserFormData_whenLoggingIn_thenReturnsExpectedStatusCode() {

    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);

    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenInvalidUserFormData_whenLoggingIn_thenReturnsExpectedStatusCode() {

    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        USER_INVALID_PWD);

    assertEquals(response.statusCode(), Status.BAD_REQUEST.getStatusCode());
  }

  @Test
  void givenValidUserFormData_whenLoggingIn_thenReturnsJWTToken() {

    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);
    String token = response.getBody().jsonPath()
        .getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);

    assertNotNull(token);
    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenNormalUser_whenLoggingIn_thenReturnsExpectedValues() {
    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);
    String token = response.getBody().jsonPath()
        .getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
    Claims claims = userResourceE2ETestHelper.getTokenDetails(token);

    assertEquals(userResourceE2ETestHelper.USER_NAME, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[0]));
    assertEquals(userResourceE2ETestHelper.USER_EMAIL, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[1]));
    assertEquals(DEFAULT_USER_ROLE, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[2]));
    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenAdminUser_whenLoggingIn_thenReturnsExpectedValues() {
    response = userResourceE2ETestHelper.loginUser(ADMIN_USER_EMAIL, ADMIN_USER_PWD);
    String token = response.getBody().jsonPath()
        .getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
    Claims claims = userResourceE2ETestHelper.getTokenDetails(token);

    assertEquals(ADMIN_USER_NAME, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[0]));
    assertEquals(ADMIN_USER_EMAIL, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[1]));
    assertEquals(ADMIN_USER_ROLE, claims.get(JWT_TOKEN_DETAILS_PARAMETERS[2]));
    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenValidUserFormData_whenLoggingIn_thenReturnsExpectedExpirationDate() {
    // TODO: This test is shaky, on rare occasions it will fail if seconds value
    // close to :59 and
    // the request takes a few milliseconds longer than expected to be completed
    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);
    LocalDateTime expirationDate = LocalDateTime.parse(
        response.getBody().jsonPath()
            .getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[1]))
        .truncatedTo(ChronoUnit.MINUTES);
    LocalDateTime expectedExpirationDate = LocalDateTime.now().plusSeconds(JWT_VALID_FOR_TIME)
        .truncatedTo(ChronoUnit.MINUTES);

    assertEquals(expirationDate, expectedExpirationDate);
    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenValidUserFormData_whenLoggingIn_thenThrowsExceptionIfInvalidJWT() {
    response = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);

    assertThrows(InvalidAuthenticationTokenException.class,
        () -> userResourceE2ETestHelper.getTokenDetails(INVALID_JWT_TOKEN));
  }

  @Test
  void givenValidActivationToken_whenActivatingAccount_thenReturnsExpectedStatusCode() {
    userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);

    response = userResourceE2ETestHelper.activateAccount(validActivationToken);

    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenInvalidActivationToken_whenActivatingAccount_thenReturnsExpectedStatusCode() {
    userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD);

    response = userResourceE2ETestHelper.activateAccount(INVALID_ACTIVATION_TOKEN);

    assertEquals(response.statusCode(), Status.UNAUTHORIZED.getStatusCode());
  }

  @Test
  void givenValidAccount_whenUnlockingBike_thenReturnsExpectedStatusCode() {
    String token = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD).getBody()
        .jsonPath().getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
    userResourceE2ETestHelper.activateAccount(validActivationToken);

    subscriptionResourceE2ETestHelper.addSubscription(VALID_SUBSCRIPTION_TYPE, token);
    response = userResourceE2ETestHelper.sendUniqueCode(token);

    assertEquals(response.statusCode(), Status.OK.getStatusCode());
  }

  @Test
  void givenInvalidAccount_whenUnlockingBike_thenReturnsExpectedStatusCode() {
    String token = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD).getBody()
        .jsonPath().getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
    userResourceE2ETestHelper.activateAccount(validActivationToken);

    response = userResourceE2ETestHelper.sendUniqueCode(token);

    assertEquals(response.statusCode(), Status.UNAUTHORIZED.getStatusCode());
  }

  @Test
  void givenUserWithValidPermissions_whenAccessingProtectedRequest_thenReturnsExpectedStatusCode() {
    String token = userResourceE2ETestHelper.loginUser(ADMIN_USER_EMAIL, ADMIN_USER_PWD).getBody()
        .jsonPath()
        .getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);

    response = userResourceE2ETestHelper.getProtectedRequest(token);

    assertEquals(response.statusCode(), Status.ACCEPTED.getStatusCode());
  }

  @Test
  void givenUserWithInsufficientPermissions_whenAccessingProtectedRequest_thenReturnsExpectedStatusCode() {
    String token = userResourceE2ETestHelper.loginUser(userResourceE2ETestHelper.USER_EMAIL,
        userResourceE2ETestHelper.USER_VALID_PWD).getBody()
        .jsonPath().getString(userResourceE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);

    response = userResourceE2ETestHelper.getProtectedRequest(token);

    assertEquals(response.statusCode(), Status.FORBIDDEN.getStatusCode());
  }

}
