package ca.ulaval.glo4003.sulvlo.unitTests.domain.station;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import ca.ulaval.glo4003.sulvlo.api.station.dto.BikesAvailabilitiesDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;
import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.bike.BikesAvailabilitiesAssembler;
import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.station.StationAssembler;
import ca.ulaval.glo4003.sulvlo.domain.station.StationRepository;
import ca.ulaval.glo4003.sulvlo.domain.station.StationService;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelFactory;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserRepository;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class StationServiceTest {
  private static final UnlockBikeRequest VALID_UNLOCK_BIKE_REQUEST =
      new UnlockBikeRequest().create("1234567890", "TES", "1");
  private static final ReturnBikeRequest VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION =
      new ReturnBikeRequest().create("TES", "1", "TES", "1");
  public static final int NUMBER_OF_AVAILABLE_BIKES = 7;
  public static final int NUMBER_OF_TAKEN_BIKES = 10;

  @Mock
  private UserRepository userRepository;

  @Mock
  private TravelRepository travelRepository;

  @Mock
  private TravelFactory travelFactory;

  @Mock
  private StationRepository stationRepository;

  @Mock
  private StationAssembler stationAssembler;

  @Mock
  private BikesAvailabilitiesAssembler bikesAvailabilitiesAssembler;

  @Mock
  private Station station;

  @Mock
  private Bike bike;

  @Mock
  private User user;

  @Mock
  private EmailSender emailSender;

  private StationService stationService;
  private List<Station> stationsList;
  private BikesAvailabilitiesDto bikesAvailabilitiesDto;

  @BeforeEach
  public void StationServiceSetup() {
    MockitoAnnotations.openMocks(this);
    stationService = new StationService(userRepository, travelRepository, stationRepository, stationAssembler,
            bikesAvailabilitiesAssembler,
            travelFactory, emailSender);
    stationsList = new ArrayList<>() {{
      add(station);
    }};
  }

  @Test
  public void whenFindAllStations_thenStationRepositoryFindAllShouldBeCalled() {
    stationService.findAllAvailableStations();

    verify(stationRepository, times(1)).findAllAvailable();
  }

  @Test
  public void givenAStationRepositoryWithOneStation_whenFindAllStations_thenStationRechargeBikesShouldBeCalled() {
    when(stationRepository.findAllAvailable()).thenReturn(stationsList);

    stationService.findAllAvailableStations();

    verify(station, times(1)).rechargeBikes();
  }

  @Test
  public void givenAStationRepositoryWithOneStation_whenFindAllStations_thenStationAssemblerCreateStationDtoShouldBeCalled() {
    List<Station> stationList = new ArrayList<>() {{
      add(station);
    }};
    when(stationRepository.findAllAvailable()).thenReturn(stationList);

    stationService.findAllAvailableStations();

    verify(stationAssembler, times(1)).createStationDto(station);
  }

  @Test
  public void givenAUnlockBikeRequest_whenUnlockBike_thenBikeSetCurrentUserShouldBeCalled() {
    when(userRepository.getUserByUniqueCode(VALID_UNLOCK_BIKE_REQUEST.userCode())).thenReturn(user);
    when(stationRepository.findAvailableByCode(VALID_UNLOCK_BIKE_REQUEST.stationCode())).thenReturn(station);
    when(station.findAvailableBikeByLocation(
        Integer.parseInt(VALID_UNLOCK_BIKE_REQUEST.bikeLocation()))).thenReturn(bike);
    when(stationRepository.findAllStations()).thenReturn(stationsList);
    createMockDependenciesForStationBikes();

    stationService.unlockBike(VALID_UNLOCK_BIKE_REQUEST);

    verify(bike, times(1)).setCurrentUser(user);
  }

  @Test
  public void givenAValidUnlockBikeRequest_whenUnlockBike_thenStationUnlockBikeShouldBeCalled() {
    when(userRepository.getUserByUniqueCode(VALID_UNLOCK_BIKE_REQUEST.userCode())).thenReturn(user);
    when(stationRepository.findAvailableByCode(VALID_UNLOCK_BIKE_REQUEST.stationCode())).thenReturn(station);
    when(station.findAvailableBikeByLocation(
        Integer.parseInt(VALID_UNLOCK_BIKE_REQUEST.bikeLocation()))).thenReturn(bike);
    when(stationRepository.findAllStations()).thenReturn(stationsList);
    createMockDependenciesForStationBikes();

    stationService.unlockBike(VALID_UNLOCK_BIKE_REQUEST);

    verify(station, times(1)).unlockBike(bike);
  }

  @Test
  public void givenAValidUnlockBikeRequest_whenUnlockBike_thenStationRepositorySaveAvailableShouldBeCalled() {
    when(userRepository.getUserByUniqueCode(VALID_UNLOCK_BIKE_REQUEST.userCode())).thenReturn(user);
    when(stationRepository.findAvailableByCode(VALID_UNLOCK_BIKE_REQUEST.stationCode())).thenReturn(station);
    when(station.findAvailableBikeByLocation(
        Integer.parseInt(VALID_UNLOCK_BIKE_REQUEST.bikeLocation()))).thenReturn(bike);
    when(stationRepository.findAllStations()).thenReturn(stationsList);
    createMockDependenciesForStationBikes();

    stationService.unlockBike(VALID_UNLOCK_BIKE_REQUEST);

    verify(stationRepository, times(1)).saveAvailable(station);
  }

  @Test
  public void givenAValidReturnBikeRequestInSameStation_whenReturnBike_thenStationReturnBikeInSameStationShouldBeCalled() {
    when(stationRepository.findAvailableByCode(
        VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION.unlockStationCode())).thenReturn(station);
    when(station.findUnlockedBikeByLocation(Integer.parseInt(
        VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION.returnBikeLocation()))).thenReturn(bike);
    when(bike.getCurrentUser()).thenReturn(user);

    stationService.returnBike(VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION);

    verify(station, times(1)).returnBikeInSameStation(bike, 1);
  }

  @Test
  public void givenAValidReturnBikeRequestInSameStation_whenReturnBike_thenStationRepositorySaveAvailableShouldBeCalled() {
    when(stationRepository.findAvailableByCode(
        VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION.unlockStationCode())).thenReturn(station);
    when(station.findUnlockedBikeByLocation(Integer.parseInt(
        VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION.returnBikeLocation()))).thenReturn(bike);
    when(bike.getCurrentUser()).thenReturn(user);

    stationService.returnBike(VALID_RETURN_BIKE_REQUEST_IN_SAME_STATION);

    verify(stationRepository, times(1)).saveAvailable(station);
  }

  private void createMockDependenciesForStationBikes() {
    bikesAvailabilitiesDto = new BikesAvailabilitiesDto(NUMBER_OF_AVAILABLE_BIKES, NUMBER_OF_TAKEN_BIKES);
    when(station.getNumberOfAvailableBikes()).thenReturn(NUMBER_OF_AVAILABLE_BIKES);
    when(station.getNumberOfTakenBikes()).thenReturn(NUMBER_OF_TAKEN_BIKES);
    when(bikesAvailabilitiesAssembler.create(NUMBER_OF_AVAILABLE_BIKES, NUMBER_OF_TAKEN_BIKES)).thenReturn(bikesAvailabilitiesDto);
  }

}
