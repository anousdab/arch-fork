package ca.ulaval.glo4003.sulvlo.unitTests.api.travel;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import ca.ulaval.glo4003.sulvlo.api.travel.TravelResource;
import ca.ulaval.glo4003.sulvlo.api.travel.TravelResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelDto;
import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelHistorySummaryDTO;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelService;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import jakarta.ws.rs.BadRequestException;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TravelResourceTest {

  @Mock
  private TravelService travelService;
  private TravelResource travelResource;
  private TravelDto travelDto;
  private List<TravelDto> travelDtoList;
  private TravelHistorySummaryDTO travelHistorySummaryDTO;

  private static final Month MONTH = Month.OCTOBER;
  private static final String USER_ID = "1";
  private static final String ID = "777";
  private static final String STATION_START_TRAVEL = "test";
  private static final String STATION_END_TRAVEL = "test2";
  private static final String START_TRAVEL_DATE = "2022-01-10 08:00:00";
  private static final String END_TRAVEL_DATE = "2022-01-10 08:30:00";
  private static final String INVALID_MONTH = "this is a test";
  private static final String TOTAL_TRAVEL_TIME = "50000";
  private static final String AVERAGE_TRAVEL_TIME = "50000";
  private static final String FAVORITE_STATION = "PLT";
  private static final int NUMBER_OF_TRAVELS = 5000;


  @BeforeEach
  void setUp() {

    travelResource = new TravelResourceImpl(travelService);
    travelDto = new TravelDto(ID, USER_ID, STATION_START_TRAVEL,
        START_TRAVEL_DATE, END_TRAVEL_DATE, STATION_END_TRAVEL, MONTH);
    travelDtoList = new ArrayList<>();
    travelDtoList.add(travelDto);
  }

  @Test
  void WhenGetAllTravel_ThenShouldReturnListOfTravels() {
    when(travelService.getAllTravelsFilteredByMonth(MONTH.toString(), USER_ID)).thenReturn(
        travelDtoList);

    assertNotNull(travelResource.getAllTravelsByMonth(MONTH.toString(), USER_ID));
  }

  @Test
  void givenAInvalidMonth_whenGetAllTravelsByMonth_ThenShouldThrowException() {
    BadRequestException thrown = assertThrows(
        BadRequestException.class, () ->
            travelResource.getAllTravelsByMonth(INVALID_MONTH, USER_ID));

    assertNotNull(thrown);
  }

  @Test
  void givenATravelId_WhenGettingTravel_ThenShouldReturnTravelDto()
      throws InvalidTravelIdException {
    when(travelService.getTravelById(ID)).thenReturn(travelDto);

    assertNotNull(travelResource.getTravelById(ID).getEntity());
  }

  @Test
  void whenGettingAllTravelsSummaryInformation_ThenShouldReturnTravelHistorySummaryDto()
      throws Exception {
    travelHistorySummaryDTO = new TravelHistorySummaryDTO(TOTAL_TRAVEL_TIME, AVERAGE_TRAVEL_TIME,
        NUMBER_OF_TRAVELS, FAVORITE_STATION);
    when(travelService.getTravelHistorySummary(anyString())).thenReturn(travelHistorySummaryDTO);

    assertNotNull(travelResource.getTravelHistorySummary(anyString()).getEntity());
  }
}
