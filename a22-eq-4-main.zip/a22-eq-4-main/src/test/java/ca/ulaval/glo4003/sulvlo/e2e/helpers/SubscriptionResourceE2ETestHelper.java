package ca.ulaval.glo4003.sulvlo.e2e.helpers;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.json.JSONObject;

public class SubscriptionResourceE2ETestHelper extends BaseE2ETestHelper {

  private JSONObject jsonObject;

  private static final String SUBSCRIPTION_PATH = "api/subscriptions";
  private static final String SUBSCRIPTION_SEMESTER = "H2023";
  private static final String USER_CREDIT_CARD = "1234567891234567";
  private static final int USER_CREDIT_CARD_EXPIRATION_MONTH = 12;
  private static final int USER_CREDIT_CARD_EXPIRATION_YEAR = 2045;
  private static final int USER_CREDIT_CARD_CCV = 123;
  private static final boolean SUBSCRIPTION_SAVE_PAYMENT = true;
  private static final boolean SUBSCRIPTION_IMMEDIATE_PAYMENT = true;
  private static final String SUBSCRIPTION_TYPE_PARAMETER = "type";
  private static final String[] ADD_SUBSCRIPTION_BODY_PARAMETERS = {"subscriptionType", "semester",
      "email", "creditCardNumber", "expirationMonth",
      "expirationYear", "ccv", "savePayment", "immediatePayment"};

  public Response addSubscription(String subscriptionType, String token) {
    jsonObject = new JSONObject()
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[0], subscriptionType)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[1], SUBSCRIPTION_SEMESTER)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[2], USER_EMAIL)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[3], USER_CREDIT_CARD)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[4], USER_CREDIT_CARD_EXPIRATION_MONTH)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[5], USER_CREDIT_CARD_EXPIRATION_YEAR)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[6], USER_CREDIT_CARD_CCV)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[7], SUBSCRIPTION_SAVE_PAYMENT)
        .put(ADD_SUBSCRIPTION_BODY_PARAMETERS[8], SUBSCRIPTION_IMMEDIATE_PAYMENT);

    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .body(jsonObject.toString())
        .header(PROTECTED_REQUEST_HEADER_PARAMETER, PROTECTED_REQUEST_HEADER + token)
        .when()
        .post(SUBSCRIPTION_PATH)
        .then()
        .extract()
        .response();
  }

  public Response getAllSubscriptions() {
    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .when()
        .get(SUBSCRIPTION_PATH)
        .then()
        .extract()
        .response();
  }

  public List convertSubscriptionsToTypes(List<Map<String, Object>> listOfSubscriptions) {
    List listOfTypes = listOfSubscriptions
        .stream()
        .map(m -> Stream.of(SUBSCRIPTION_TYPE_PARAMETER)
            .filter(m::containsKey)
            .collect(Collectors.toMap(key -> key, m::get))
            .entrySet()
            .stream()
            .map(x -> x.getValue())
            .collect(Collectors.toList()))
        .toList()
        .stream()
        .flatMap(Collection::stream)
        .collect(Collectors.toList());
    return listOfTypes;
  }

}
