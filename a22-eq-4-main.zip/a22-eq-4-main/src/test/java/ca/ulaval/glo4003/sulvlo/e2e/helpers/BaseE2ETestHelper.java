package ca.ulaval.glo4003.sulvlo.e2e.helpers;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;


public class BaseE2ETestHelper {

  // Ici c'est la seule classe ou on peut avoir des variables public pour eviter la duplication, aucune autre variable public dans les autres classes
  // Si on utilise la variable en question dans deux ou plus differents fichier => on la set public ici, sinon => set private dans sa classe de test
  private JSONObject jsonObject;
  public static final String CONTENT_TYPE = "application/json";
  public static final String BASE_PATH = "api/users";
  private static final String REGISTER_PATH = "/register";
  private static final String LOGIN_PATH = "/login";

  public static final String USER_NAME = "Normal User";
  public static final String USER_EMAIL = "normalUser@mail.com";
  public static final String USER_VALID_PWD = "xXuser69Xx";
  public static final int USER_AGE = 69;
  public static final String REGISTER_USER_HEADER_RESPONSE_PARAMETER = "activationToken";
  public static final String PROTECTED_REQUEST_HEADER_PARAMETER = "Authorization";
  public static final String PROTECTED_REQUEST_HEADER = "Bearer ";
  public static final String[] LOGIN_USER_BODY_RESPONSE_PARAMETERS = {"token", "expireIn"};
  private static final String USER_IDUL = "user69";
  private static final String USER_BIRTH_DATE = "30/12/2011";
  private static final String USER_GENDER = "MALE";

  private static final String[] REGISTER_USER_BODY_PARAMETERS = {"name", "email", "idul", "age",
      "password", "birthDate", "gender"};


  public Response registerUser() {
    jsonObject = new JSONObject()
        .put(REGISTER_USER_BODY_PARAMETERS[0], USER_NAME)
        .put(REGISTER_USER_BODY_PARAMETERS[1], USER_EMAIL)
        .put(REGISTER_USER_BODY_PARAMETERS[2], USER_IDUL)
        .put(REGISTER_USER_BODY_PARAMETERS[3], USER_AGE)
        .put(REGISTER_USER_BODY_PARAMETERS[4], USER_VALID_PWD)
        .put(REGISTER_USER_BODY_PARAMETERS[5], USER_BIRTH_DATE)
        .put(REGISTER_USER_BODY_PARAMETERS[6], USER_GENDER);

    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .body(jsonObject.toString())
        .when()
        .post(BASE_PATH + REGISTER_PATH)
        .then()
        .extract()
        .response();
  }

  public Response loginUser(String email, String pwd) {
    jsonObject = new JSONObject()
        .put(REGISTER_USER_BODY_PARAMETERS[1], email)
        .put(REGISTER_USER_BODY_PARAMETERS[4], pwd);

    return RestAssured.given()
        .contentType(CONTENT_TYPE)
        .body(jsonObject.toString())
        .when()
        .post(BASE_PATH + LOGIN_PATH)
        .then()
        .extract()
        .response();
  }

}
