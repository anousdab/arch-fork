// package ca.ulaval.glo4003.sulvlo.domain.payment;


// import static ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionTestHelper.CREDIT_CARD;
// import static ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionTestHelper.PRICE;
// import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.BDDMockito.given;

// import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentAutorizer;
// import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentProcessor;
// import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
// import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionTestHelper;
// import ca.ulaval.glo4003.sulvlo.domain.payment.exception.PaymentNotAutorized;
// import ca.ulaval.glo4003.sulvlo.domain.payment.information.PaymentInformation;
// import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;
// import java.math.BigDecimal;
// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.Mock;
// import org.mockito.Mockito;
// import org.mockito.junit.jupiter.MockitoExtension;

// @ExtendWith(MockitoExtension.class)
// class PaymentProcessorTest {

//   private static final BigDecimal ZERO = new BigDecimal(0);
//   private static final boolean SAVE_PAYMENT = true;
//   private static final boolean IMMEDIATE_PAYMENT = true;
//   private static final boolean DONT_SAVE_PAYMENT = false;
//   private static final boolean PAY_LATER = false;
//   @Mock
//   private PaymentAutorizer paymentAutorizer;
//   private BankAccount bankAccount;
//   private PaymentProcessor paymentProcessor;
//   private SubscriptionTestHelper subscriptionTestHelper;

//   @BeforeEach
//   void setup() {
//     paymentProcessor = new PaymentProcessor(paymentAutorizer);
//     bankAccount = new BankAccount();
//     subscriptionTestHelper = new SubscriptionTestHelper();
//   }

//   @Test
//   void givenASubscription_whenProcess_ThrowIllegalAccessError() {
//     Subscription subscription = subscriptionTestHelper.createSubscription(SAVE_PAYMENT,
//         IMMEDIATE_PAYMENT);
//     given(paymentAutorizer.autorize(any(PaymentInformation.class))).willReturn(false);

//     assertThrows(PaymentNotAutorized.class,
//         () -> paymentProcessor.procesSubscriptionPayment(bankAccount, subscription));
//   }


//   @Test
//   void givenASubscriptionWithSavePaymentAndWithImmediatePayment_whenProcess_ThenCreditCardIsSavedAndBankAccountIsNotBilled() {
//     Subscription subscription = subscriptionTestHelper.createSubscription(SAVE_PAYMENT,
//         IMMEDIATE_PAYMENT);
//     given(paymentAutorizer.autorize(any(PaymentInformation.class))).willReturn(true);

//     BankAccount bankAccountAfterProcessing = paymentProcessor.procesSubscriptionPayment(bankAccount, subscription);

//     assertThat(bankAccount.getSavedCreditCard()).isEqualTo(CREDIT_CARD);
//     assertThat(bankAccountAfterProcessing.getDebt()).isEqualTo(ZERO);
//   }

//   @Test
//   void givenASubscriptionWithoutSavePaymentAndImmediatePayment_whenProcess_ThenUpdateBankAccount() {
//     Subscription subscription = subscriptionTestHelper.createSubscription(DONT_SAVE_PAYMENT,
//         IMMEDIATE_PAYMENT);
//     given(paymentAutorizer.autorize(any(PaymentInformation.class))).willReturn(true);

//     BankAccount bankAccountAfterProcessing = paymentProcessor.procesSubscriptionPayment(bankAccount, subscription);

//     Mockito.verify(paymentAutorizer).autorize(any(PaymentInformation.class));
//     assertThat(bankAccountAfterProcessing.getDebt()).isEqualTo(ZERO);
//     assertThat(bankAccount.getSavedCreditCard()).isNull();

//   }

//   @Test
//   void givenASubscriptionWithoutSavePaymentAndWithoutImmediatePayment_whenProcess_ThenUpdateBankAccount() {
//     Subscription subscription = subscriptionTestHelper.createSubscription(DONT_SAVE_PAYMENT,
//         PAY_LATER);

//     BankAccount bankAccountAfterProcessing = paymentProcessor.procesSubscriptionPayment(bankAccount, subscription);

//     var expectedBalance = new BigDecimal(PRICE);
//     assertThat(bankAccountAfterProcessing.getDebt()).isEqualTo(expectedBalance);
//     assertThat(bankAccount.getSavedCreditCard()).isNull();
//   }

//   @Test
//   void givenASubscriptionWithSavePaymentAndWithoutImmediatePayment_whenProcess_ThenUpdateBankAccount() {
//     Subscription subscription = subscriptionTestHelper.createSubscription(SAVE_PAYMENT, PAY_LATER);

//     BankAccount bankAccountAfterProcessing = paymentProcessor.procesSubscriptionPayment(bankAccount, subscription);

//     var expectedBalance = new BigDecimal(PRICE);
//     assertThat(bankAccountAfterProcessing.getDebt()).isEqualTo(expectedBalance);
//     assertThat(bankAccount.getSavedCreditCard()).isEqualTo(CREDIT_CARD);
//   }


// }