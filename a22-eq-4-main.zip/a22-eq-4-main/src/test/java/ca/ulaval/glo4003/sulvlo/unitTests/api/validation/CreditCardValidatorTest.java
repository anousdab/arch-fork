package ca.ulaval.glo4003.sulvlo.unitTests.api.validation;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import ca.ulaval.glo4003.sulvlo.api.validation.exception.InvalidSubscriptionParameterException;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CreditCardValidatorTest {

  private static final String SUBSCRIPTION_TYPE = "Premium";
  private static final String SEMESTER = "H2023";
  private static final String EMAIL = "unMail@gmail.com";
  private static final String CREDIT_CARD_NUMBER = "1234567891234567";
  private static final String INVALID_CREDIT_CARD_NUMBER = "invalid";
  private static final int EXPIRATION_MONTH = 12;
  private static final int EXPIRATION_YEAR = 2045;
  private static final int CCV = 123;
  private static final int INVALID_CCV = 12345;
  private static final boolean SAVE_PAYMENT = true;
  private static final boolean IMMEDIATE_PAYMENT = true;
  private static final LocalDate LOCAL_DATE = LocalDate.now();
  private static final int CURRENT_MONTH = LOCAL_DATE.getMonthValue();
  private static final int CURRENT_YEAR = LOCAL_DATE.getYear();
  private static final int PAST_MONTH = CURRENT_MONTH - 1;

  private SubscriptionDto subscriptionDto;
  private ValidatorMediator validatorMediator;

  @BeforeEach
  void setup() {
    validatorMediator = new ValidatorMediator();
  }

  @Test
  void givenSubscriptionDtoWithInvalidCreditCardNumber_whenValidateCreditCard_thenThrowInvalidSubscriptionParameterException() {
    subscriptionDto = createSubscriptionDto(INVALID_CREDIT_CARD_NUMBER, EXPIRATION_MONTH,
        EXPIRATION_YEAR, CCV);

    assertThrows(InvalidSubscriptionParameterException.class,
        () -> validatorMediator.validCreditCard(subscriptionDto));
  }

  @Test
  void givenSubscriptionDto_whenValidateCreditCard_shouldNotThrowException() {
    subscriptionDto = createSubscriptionDto(CREDIT_CARD_NUMBER, EXPIRATION_MONTH, EXPIRATION_YEAR,
        CCV);

    assertDoesNotThrow(() -> validatorMediator.validCreditCard(subscriptionDto));
  }

  @Test
  void givenSubscriptionDtoWithInvalidCreditCardMonth_whenValidateCreditCard_thenThrowInvalidSubscriptionParameterException() {
    subscriptionDto = createSubscriptionDto(CREDIT_CARD_NUMBER, PAST_MONTH, CURRENT_YEAR, CCV);

    assertThrows(InvalidSubscriptionParameterException.class,
        () -> validatorMediator.validCreditCard(subscriptionDto));
  }

  @Test
  void givenSubscriptionDtoWithInvalidCreditCardCCV_whenValidate_thenThrowInvalidSubscriptionParameterException() {
    subscriptionDto = createSubscriptionDto(CREDIT_CARD_NUMBER, EXPIRATION_MONTH, EXPIRATION_YEAR,
        INVALID_CCV);

    assertThrows(InvalidSubscriptionParameterException.class,
        () -> validatorMediator.validCreditCard(subscriptionDto));
  }

  private SubscriptionDto createSubscriptionDto(String creditCardNumber, int expirationMonth,
      int expirationYear, int ccv) {
    return new SubscriptionDto(SUBSCRIPTION_TYPE,
        SEMESTER, EMAIL,
        creditCardNumber, expirationMonth, expirationYear,
        ccv, SAVE_PAYMENT, IMMEDIATE_PAYMENT);
  }
}
