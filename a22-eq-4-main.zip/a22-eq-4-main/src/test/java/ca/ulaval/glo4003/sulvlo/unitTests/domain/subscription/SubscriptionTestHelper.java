package ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription;

import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardInformation;
import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionType;
import ca.ulaval.glo4003.sulvlo.domain.util.semester.Semester;

public class SubscriptionTestHelper {

  public static final String TYPE = "base";
  public static final int PRICE = 1;
  public static final String DESCRIPTION = "description";
  public static final int DURATION = 10;
  public static final SubscriptionType SUBSCRIPTION_TYPE = new SubscriptionType(TYPE, PRICE,
      DESCRIPTION, DURATION);
  public static final String CREDIT_CARD_NUMBER = "creditCardHash";
  public static final int EXPIRATION_MONTH = 1;
  public static final int EXPIRATION_DAY = 20;
  public static final int CCV = 111;
  public static final CreditCardInformation CREDIT_CARD = new CreditCardInformation(CREDIT_CARD_NUMBER, EXPIRATION_MONTH,
      EXPIRATION_DAY,
      CCV);
  public static final String EMAIL = "cabiva1@gmail.com";
  public static final Semester SEMESTER = new Semester("H", 2023);


  public Subscription createSubscription(boolean savePayment, boolean immediatePayment) {
    return new Subscription(SUBSCRIPTION_TYPE, EMAIL,
        CREDIT_CARD, SEMESTER, savePayment, immediatePayment);
  }


}
