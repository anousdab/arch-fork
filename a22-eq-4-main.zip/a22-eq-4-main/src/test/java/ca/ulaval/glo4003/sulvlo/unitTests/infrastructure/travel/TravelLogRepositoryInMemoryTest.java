package ca.ulaval.glo4003.sulvlo.unitTests.infrastructure.travel;

import ca.ulaval.glo4003.sulvlo.domain.travel.Travel;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelRepository;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.TravelLogRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class TravelLogRepositoryInMemoryTest {

  private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern(
      "yyyy-MM-dd HH:mm:ss");
  private Travel travel;
  private static TravelRepository travelLogRepositoryInMemory;

  private static String ERROR_MESSAGE = "There is no travel with that ID, please try again!";
  private static String STRAT_TIME_TRAVEL = "2022-01-10 08:00:00";
  private static String END_TIME_TRAVEL = "2022-01-10 08:40:00";
  private static String STATION_CODE_END = "TEST2";
  private static String SATION_CODE_BEGIN = "TEST777";
  private static String USER_ID = "1";


  @BeforeEach
  public void setUp() throws ParseException {
    travel = new Travel(UUID.randomUUID(), USER_ID, SATION_CODE_BEGIN,
        LocalDateTime.parse(STRAT_TIME_TRAVEL, FORMATTER),
        LocalDateTime.parse(END_TIME_TRAVEL, FORMATTER),
        STATION_CODE_END, Month.OCTOBER);

    travelLogRepositoryInMemory = new TravelLogRepositoryInMemory();
  }

  @Test
  void givenATravel_WhenTryingToAddToDataBase_ThenShouldSaveTravelInMemory() {
    int beforeSave = travelLogRepositoryInMemory.getTravelListSize();
    travelLogRepositoryInMemory.save(travel);
    assertEquals(beforeSave + 1, travelLogRepositoryInMemory.getTravelListSize());
  }

  @Test
  void whenTryingToRetrieveEveryTravelDone_ShouldReturnListOfTravels() {
    travelLogRepositoryInMemory.save(travel);
    assertTrue(travelLogRepositoryInMemory.getAllTravels().contains(travel));
  }

  @Test
  void givenAUUID_WhenTryingToLocaleTravelInMemory_ThenShouldReturnTravel()
      throws InvalidTravelIdException {
    UUID getTravelId = travel.travelId();
    travelLogRepositoryInMemory.save(travel);
    assertNotNull(travelLogRepositoryInMemory.getTravel(getTravelId));
  }

  @Test
  void givenAWrongUUID_WhenTryingToLocateTravelInMemory_ThenShouldThrowException() {
    UUID id = UUID.randomUUID();
    travelLogRepositoryInMemory.save(travel);

    InvalidTravelIdException thrown = assertThrows(
        InvalidTravelIdException.class,
        () -> travelLogRepositoryInMemory.getTravel(id)
    );
    assertTrue(thrown.getMessage().contains(ERROR_MESSAGE));
  }
}
