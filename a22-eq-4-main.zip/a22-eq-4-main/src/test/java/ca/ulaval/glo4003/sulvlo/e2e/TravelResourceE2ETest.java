package ca.ulaval.glo4003.sulvlo.e2e;

import static org.junit.jupiter.api.Assertions.assertEquals;

import ca.ulaval.glo4003.SulvloMain;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.BaseE2ETestHelper;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.TravelResourceE2ETestHelper;
import ca.ulaval.glo4003.sulvlo.e2e.helpers.UserResourceE2ETestHelper;
import io.restassured.RestAssured;
import io.restassured.common.mapper.TypeRef;
import io.restassured.response.Response;
import jakarta.ws.rs.core.Response.Status;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.quartz.SchedulerException;

public class TravelResourceE2ETest {

  private static final String VALID_TRAVELER_USER_ID = "1";
  private static final String INVALID_TRAVELER_USER_ID = "TROLOLOL";
  private static final String TRAVELER_MONTH_CHOSEN = "APRIL";
  private static final String TRAVEL_ID_RESPONSE_PARAMETER = "Id";
  private static final int EXPECTED_NUMBER_OF_TRAVELS_FOR_CHOSEN_MONTH = 1;
  private static final int EXPECTED_NUMBER_OF_ALL_TRAVELS = 8;
  private static final String INVALID_TRAVEL_ID = "TROLOLOL";
  private static final String[] REQUEST_RESPONSE_PARAMETER = {"error", "message"};
  private static final String INVALID_TRAVEL_ID_REQUEST_PARAMETER_MSG = "There is no travel with that ID, please try again!";
  private static final String INVALID_USER_ID_REQUEST_PARAMETER_MSG = "You have entered an invalid user ID!";

  private SulvloMain server;
  private Response response;
  private String validActivationToken;
  private String jwtToken;
  private String validTravelId;
  private final UserResourceE2ETestHelper userResourceE2ETestHelper;
  private final TravelResourceE2ETestHelper travelResourceE2ETestHelper;

  // TODO: ameliorer la structure des classes de tests e2e, peut etre avec composition en initialisant
  //  tout les helper une fois ou en ajoutant des attributs a leurs constructeurs
  public TravelResourceE2ETest() {
    this.userResourceE2ETestHelper = new UserResourceE2ETestHelper();
    this.travelResourceE2ETestHelper = new TravelResourceE2ETestHelper();
  }

  @BeforeEach
  public void setUp() throws SchedulerException {
    RestAssured.port = 8080;
    server = new SulvloMain();
    server.run();

    response = userResourceE2ETestHelper.registerUser();

    validActivationToken = response.getHeaders()
        .getValue(BaseE2ETestHelper.REGISTER_USER_HEADER_RESPONSE_PARAMETER);

    jwtToken = userResourceE2ETestHelper.loginUser(BaseE2ETestHelper.USER_EMAIL,
            BaseE2ETestHelper.USER_VALID_PWD).getBody()
        .jsonPath().getString(BaseE2ETestHelper.LOGIN_USER_BODY_RESPONSE_PARAMETERS[0]);
  }

  @AfterEach
  public void tearDown() {
    server.stopServer();
  }

  @Test
  void givenValidParameters_whenGettingTravelsByMonth_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getAllTravelsByMonth(VALID_TRAVELER_USER_ID,
        TRAVELER_MONTH_CHOSEN);

    assertEquals(Status.OK.getStatusCode(), response.statusCode());
  }

  @Test
  void givenValidParameters_whenGettingTravelsByMonth_thenReturnsExpectedValues() {
    response = travelResourceE2ETestHelper.getAllTravelsByMonth(VALID_TRAVELER_USER_ID,
        TRAVELER_MONTH_CHOSEN);
    List<Map<String, Object>> listOfDefaultAprilTravels = response.body().as(new TypeRef<>() {
    });

    assertEquals(EXPECTED_NUMBER_OF_TRAVELS_FOR_CHOSEN_MONTH, listOfDefaultAprilTravels.size());
  }

  @Test
  void whenGettingAllTravels_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getAllTravels();

    assertEquals(Status.OK.getStatusCode(), response.statusCode());
  }

  @Test
  void whenGettingAllTravels_thenReturnsExpectedValues() {
    response = travelResourceE2ETestHelper.getAllTravels();
    List<Map<String, Object>> listOfAllTravels = response.body().as(new TypeRef<>() {
    });

    assertEquals(EXPECTED_NUMBER_OF_ALL_TRAVELS, listOfAllTravels.size());
  }

  @Test
  void givenExistingTravelId_whenGettingATravelById_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getAllTravels();
    List<Map<String, Object>> listOfAllTravels = response.body().as(new TypeRef<>() {
    });
    validTravelId = travelResourceE2ETestHelper.getFirstTravelId(listOfAllTravels);

    response = travelResourceE2ETestHelper.getAllTravelsById(validTravelId);

    assertEquals(Status.OK.getStatusCode(), response.statusCode());
  }

  @Test
  void givenExistingTravelId_whenGettingATravelById_thenReturnsExpectedValue() {
    response = travelResourceE2ETestHelper.getAllTravels();
    List<Map<String, Object>> listOfAllTravels = response.body().as(new TypeRef<>() {
    });
    validTravelId = travelResourceE2ETestHelper.getFirstTravelId(listOfAllTravels);

    response = travelResourceE2ETestHelper.getAllTravelsById(validTravelId);
    String travelId = response.getBody().jsonPath().getString(TRAVEL_ID_RESPONSE_PARAMETER);

    assertEquals(validTravelId, travelId);
  }

  @Test
  void givenInexistingTravelId_whenGettingATravelById_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getAllTravelsById(INVALID_TRAVEL_ID);

    assertEquals(Status.BAD_REQUEST.getStatusCode(), response.statusCode());
  }

  @Test
  void givenInexistingTravelId_whenGettingATravelById_thenReturnsExpectedErrorMsg() {
    response = travelResourceE2ETestHelper.getAllTravelsById(INVALID_TRAVEL_ID);
    LinkedHashMap<String, String> map = response.getBody().jsonPath()
        .get(REQUEST_RESPONSE_PARAMETER[0]);
    String errorMsg = map.get(REQUEST_RESPONSE_PARAMETER[1]);

    assertEquals(INVALID_TRAVEL_ID_REQUEST_PARAMETER_MSG, errorMsg);
  }

  @Test
  void givenValidUserId_whenGettingTravelHistorySummary_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getTravelHistorySummary(VALID_TRAVELER_USER_ID);

    assertEquals(Status.OK.getStatusCode(), response.statusCode());
  }

  @Test
  void givenInvalidUserId_whenGettingTravelHistorySummary_thenReturnsExpectedStatusCode() {
    response = travelResourceE2ETestHelper.getTravelHistorySummary(INVALID_TRAVELER_USER_ID);

    assertEquals(Status.BAD_REQUEST.getStatusCode(), response.statusCode());
  }

  @Test
  void givenInvalidUserId_whenGettingTravelHistorySummary_thenReturnsExpectedErrorMsg() {
    response = travelResourceE2ETestHelper.getTravelHistorySummary(INVALID_TRAVELER_USER_ID);
    LinkedHashMap<String, String> map = response.getBody().jsonPath()
        .get(REQUEST_RESPONSE_PARAMETER[0]);
    String errorMsg = map.get(REQUEST_RESPONSE_PARAMETER[1]);

    assertEquals(INVALID_USER_ID_REQUEST_PARAMETER_MSG, errorMsg);
  }


}
