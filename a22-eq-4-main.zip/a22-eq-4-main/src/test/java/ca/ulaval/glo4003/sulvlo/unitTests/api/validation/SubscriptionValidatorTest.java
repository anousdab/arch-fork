package ca.ulaval.glo4003.sulvlo.unitTests.api.validation;

import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import ca.ulaval.glo4003.sulvlo.api.validation.exception.InvalidSubscriptionParameterException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SubscriptionValidatorTest {

  private static final String SUBSCRIPTION_TYPE = "Premium";
  private static final String SEMESTER = "H2023";
  private static final String CREDIT_CARD_NUMBER = "12344567891234567";
  private static final int EXPIRATION_MONTH = 12;
  private static final boolean SAVE_PAYMENT = true;
  private static final boolean IMMEDIATE_PAYMENT = true;
  private static final String INVALID_EMAIL = "";
  private static final int EXPIRATION_YEAR = 2045;
  private static final int CCV = 123;
  private static final String EMAIL = "unMail@gmail.com";
  private static final String INVALID_SEMESTER = "UneMauvaiseSaison";

  private ValidatorMediator validatorMediator;

  @BeforeEach
  void setup() {
    validatorMediator = new ValidatorMediator();
  }


  @Test
  void givenSubscription_whenInvalidEmail_shouldThrowException() {
    SubscriptionDto invalidEmail = createSubscriptionDto(SEMESTER, INVALID_EMAIL);

    assertThrows(InvalidSubscriptionParameterException.class,
        () -> validatorMediator.validSubscription(invalidEmail));
  }


  @Test
  void givenSubscription_whenInvalidSemester_shouldThrowException() {
    SubscriptionDto invalidSemester = createSubscriptionDto(INVALID_SEMESTER, EMAIL);

    assertThrows(InvalidSubscriptionParameterException.class,
        () -> validatorMediator.validSubscription(invalidSemester));
  }

  private SubscriptionDto createSubscriptionDto(String semester, String invalidEmail) {
    return new SubscriptionDto(SUBSCRIPTION_TYPE,
        semester, invalidEmail, CREDIT_CARD_NUMBER,
        EXPIRATION_MONTH, EXPIRATION_YEAR, CCV,
        SAVE_PAYMENT, IMMEDIATE_PAYMENT);
  }

}
