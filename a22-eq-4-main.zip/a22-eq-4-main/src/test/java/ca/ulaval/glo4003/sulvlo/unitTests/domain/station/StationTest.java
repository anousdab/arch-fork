package ca.ulaval.glo4003.sulvlo.unitTests.domain.station;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.bike.EnergyLevel;
import ca.ulaval.glo4003.sulvlo.domain.bike.exception.BikeNotFoundException;
import ca.ulaval.glo4003.sulvlo.domain.bike.exception.BikeReturnNotImplementedException;
import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.station.exception.NoMoreEmptySpaceInThisStationException;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserType;
import ca.ulaval.glo4003.sulvlo.domain.user.information.Gender;
import ca.ulaval.glo4003.sulvlo.domain.user.information.UserInformation;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class StationTest {

  private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

  private static final LocalDateTime RETURNABLE_BIKE_UNLOCK_DATETIME = LocalDateTime.now()
      .minusMinutes(6);
  private static final LocalDateTime UNRETURNABLE_BIKE_UNLOCK_DATETIME = LocalDateTime.now()
      .minusMinutes(13);
  private static final int EXISTING_AVAILABLE_BIKE_LOCATION = 2;
  private static final int NON_EXISTING_AVAILABLE_BIKE_LOCATION = 34;
  private static final int EXISTING_UNLOCKED_BIKE_LOCATION = 3;
  private static final int ANOTHER_EXISTING_UNLOCKED_BIKE_LOCATION = 5;
  private static final int NON_EXISTING_UNLOCKED_BIKE_LOCATION = 14;
  private static final double SPECIFIC_PERCENTAGE = 0.002 * 5;
  private static final String ANY_STATION_LOCATION = "anyLocation";
  private static final String ANY_STATION_NAME = "anyName";
  private static final String ANY_STATION_CODE = "anyCode";

  public static final String USER_NAME = "Normal User";
  public static final String USER_EMAIL = "normalUser@mail.com";
  public static final String USER_PWD = "xXuser69Xx";
  public static final int USER_AGE = 69;
  private static final String USER_IDUL = "user69";
  private static final String USER_BIRTH_DATE = "30/12/2011";
  private static final UserInformation userInformation = new UserInformation(USER_NAME, USER_EMAIL,
      USER_IDUL, USER_AGE,
      LocalDate
          .parse(USER_BIRTH_DATE, formatter),
      Gender.MALE, UUID.randomUUID(), USER_PWD.hashCode());
  private static final User NORMAL_USER = new User(userInformation, null, UserType.NORMAL);

  private Bike availableBike, returnableBike, unreturnableBike;
  private Station station;

  @BeforeEach
  public void setup() {
    availableBike = new Bike(EXISTING_AVAILABLE_BIKE_LOCATION,
        new EnergyLevel(BigDecimal.valueOf(46)));
    returnableBike = new Bike(EXISTING_UNLOCKED_BIKE_LOCATION,
        new EnergyLevel(BigDecimal.valueOf(50)));
    returnableBike.setUnlockDateTime(RETURNABLE_BIKE_UNLOCK_DATETIME);
    returnableBike.setCurrentUser(NORMAL_USER);
    unreturnableBike = new Bike(ANOTHER_EXISTING_UNLOCKED_BIKE_LOCATION,
        new EnergyLevel(BigDecimal.valueOf(68)));
    unreturnableBike.setCurrentUser(NORMAL_USER);
    unreturnableBike.setUnlockDateTime(UNRETURNABLE_BIKE_UNLOCK_DATETIME);

    station = new Station(ANY_STATION_LOCATION, ANY_STATION_NAME, ANY_STATION_CODE, 1, 2,
        new ArrayList<>() {
          {
            add(availableBike);
          }
        }, new ArrayList<>() {
      {
        add(6);
        add(3);
      }
    });
    station.setCurrentDateTime(LocalDateTime.now().minusMinutes(5));
    station.setUnlockedBikes(new ArrayList<>() {
      {
        add(returnableBike);
        add(unreturnableBike);
      }
    });
  }

  @Test
  public void givenAStationWithAvailableBikes_whenFindExistingAvailableBikeByLocation_thenReturnThatBike() {
    assertEquals(availableBike,
        station.findAvailableBikeByLocation(EXISTING_AVAILABLE_BIKE_LOCATION));
  }

  @Test
  public void givenAStationWithAvailableBikes_whenFindNonExistingAvailableBikeByLocation_thenThrowBikeNotFoundException() {
    assertThrows(BikeNotFoundException.class, () -> {
      station.findAvailableBikeByLocation(NON_EXISTING_AVAILABLE_BIKE_LOCATION);
    });
  }

  @Test
  public void givenAStationWithUnlockedBikes_whenFindExistingUnlockedBikeByLocation_thenReturnThatBike() {
    assertEquals(returnableBike,
        station.findUnlockedBikeByLocation(EXISTING_UNLOCKED_BIKE_LOCATION));
  }

  @Test
  public void givenAStationWithUnlockedBikes_whenFindNonExistingUnlockedBikeByLocation_thenThrowBikeNotFoundException() {
    assertThrows(BikeNotFoundException.class, () -> {
      station.findUnlockedBikeByLocation(NON_EXISTING_UNLOCKED_BIKE_LOCATION);
    });
  }

  @Test
  public void givenAStationWithOneAvailableBike_whenRechargeBikes_thenEnergyLevelOfAllAvailableBikesShouldIncreaseByASpecificPercentage() {
    station.rechargeBikes();

    assertEquals(new EnergyLevel(new BigDecimal(46 + SPECIFIC_PERCENTAGE)),
        availableBike.getEnergyLevel());
  }

  @Test
  public void givenAStationWithOneAvailableBikeAndTwoUnlockedBikes_whenUnlockBike_thenStationShouldHaveZeroAvailableBikeAndThreeUnlockedBike() {
    station.unlockBike(availableBike);

    assertEquals(0, station.getAvailableBikes().size());
    assertEquals(3, station.getUnlockedBikes().size());
  }

  @Test
  public void givenAStationWithUnreturnableBike_whenReturnBikeInSameStation_thenThrowBikeReturnNotImplementedException() {
    assertThrows(BikeReturnNotImplementedException.class, () -> {
      station.returnBikeInSameStation(unreturnableBike, 7);
    });
  }

  @Test
  void givenAStationWithNoCapacity_whenReturnBikeInSameStation_thenThrowInvalidReturnStationException() {
    Station stationWithNoCapacity = new Station(ANY_STATION_LOCATION, ANY_STATION_NAME,
        ANY_STATION_CODE,
        15, 15, new ArrayList<>(), new ArrayList<>());
    stationWithNoCapacity.setCurrentDateTime(LocalDateTime.now().minusMinutes(5));
    stationWithNoCapacity.setUnlockedBikes(new ArrayList<>());

    assertThrows(NoMoreEmptySpaceInThisStationException.class, () -> {
      stationWithNoCapacity.returnBikeInSameStation(returnableBike, 3);
    });
  }

  @Test
  public void givenAStationWithOneAvailableBikeAndTwoUnlockedBikes_whenReturnBikeInSameStation_thenTheStationShouldHaveTwoAvailableBikes() {
    station.returnBikeInSameStation(returnableBike, 3);

    assertEquals(2, station.getAvailableBikes().size());
    assertEquals(1, station.getUnlockedBikes().size());
  }

  @Test
  public void givenDiffStation_whenReturnBikeInDiffStation_thenBikeShouldBeReturnedInThatStation() {
    Station diffStation = new Station(ANY_STATION_LOCATION, ANY_STATION_NAME, ANY_STATION_CODE, 0,
        2,
        new ArrayList<>(), new ArrayList<>() {
      {
        add(3);
      }
    });
    diffStation.setCurrentDateTime(LocalDateTime.now());
    diffStation.setUnlockedBikes(new ArrayList<>());

    diffStation.returnBikeInDiffStation(returnableBike, station, EXISTING_UNLOCKED_BIKE_LOCATION);

    assertEquals(1, diffStation.getAvailableBikes().size());
  }

}