package ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.semester;

class SemesterAssemblerTest {

}