package ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription;

import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CCV;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CREDIT_CARD;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.CREDIT_CARD_NUMBER;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EMAIL;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EXPIRATION_DAY;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.EXPIRATION_MONTH;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.SEMESTER;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.SUBSCRIPTION_TYPE;
import static ca.ulaval.glo4003.sulvlo.unitTests.domain.subscription.SubscriptionTestHelper.TYPE;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;
import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionService;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;
import ca.ulaval.glo4003.sulvlo.domain.user.information.Gender;
import ca.ulaval.glo4003.sulvlo.domain.user.information.UserInformation;

import ca.ulaval.glo4003.sulvlo.domain.user.UserType;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;


@ExtendWith(MockitoExtension.class)
class SubscriptionServiceTest {

  private static final String NAME = "name";
  private static final String IDUL = "idul";
  private static final int AGE = 20;
  private static final int HASHED_PWD = 111;
  private static final User user = new User(
      new UserInformation(NAME, EMAIL, IDUL, AGE, LocalDate.now(), Gender.MALE,
          UUID.randomUUID(), HASHED_PWD), new BankAccount(), UserType.NORMAL);
  private static final boolean SAVE_PAYMENT = true;
  private static final boolean IMMEDIATE_PAYMENT = true;
  private static final Subscription SUBSCRIPTION = new Subscription(SUBSCRIPTION_TYPE, EMAIL, CREDIT_CARD, SEMESTER, SAVE_PAYMENT, IMMEDIATE_PAYMENT);

  @Mock
  private SubscriptionTypeRepository subscriptionTypeRepository;
  @Mock
  private SubscriptionTypeAssembler subscriptionTypeAssembler;
  @Mock
  private SubscriptionAssembler subscriptionAssembler;
  @Mock
  private PaymentService paymentService;
  @Mock
  private EmailSender emailSender;

  private SubscriptionService subscriptionService;


  @BeforeEach
  void setup() {
    subscriptionService = new SubscriptionService(subscriptionTypeRepository,
        subscriptionTypeAssembler, subscriptionAssembler, paymentService);

    subscriptionService = createSubscriptionService();
  }

  @Test
  void givenSubscriptionDto_whenAddSubscription_thenSaveBankAccountAndSubscriptionAndSendEmail() {
    var subscriptionDto = new SubscriptionDto(SUBSCRIPTION_TYPE.type(), SEMESTER.toString(), EMAIL,
        CREDIT_CARD_NUMBER, EXPIRATION_MONTH, EXPIRATION_DAY, CCV, SAVE_PAYMENT, IMMEDIATE_PAYMENT);

    given(subscriptionTypeRepository.findByName(TYPE)).willReturn(SUBSCRIPTION_TYPE);
    given(subscriptionAssembler.create(SUBSCRIPTION_TYPE, subscriptionDto)).willReturn(
        SUBSCRIPTION);
    activateUser();

    subscriptionService.addSubscription(subscriptionDto);

    verify(paymentService).paySubscription(SUBSCRIPTION);
  }

  @Test
  void whenFindAllSubscriptionType_thenCallRepository() {
    subscriptionService.findAllSubscriptionType();

    verify(subscriptionTypeRepository).findAll();
  }

  private SubscriptionService createSubscriptionService() {
    return new SubscriptionService(subscriptionTypeRepository, subscriptionTypeAssembler,
        subscriptionAssembler, paymentService);
  }

  private void activateUser() {
    String token = user.getActivationToken();
    user.validateActivationToken(token);
  }

}