package ca.ulaval.glo4003.sulvlo.unitTests.api.validation;

import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import jakarta.ws.rs.BadRequestException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class UserValidatorTest {

  private final ValidatorMediator VALIDATOR = new ValidatorMediator();
  private final String NAME = "test";
  private final String TOO_LONG_NAME = "testestestestestestest";
  private final String IDUL = "test";
  private final String TOO_LONG_IDUL = "testestestest";
  private final int AGE = 11;
  private final int NEGATIVE_AGE = -11;
  private final int OVER_AGE = 123;
  private final String BIRTH_DATE = "02/02/2002";
  private final String WRONG_BIRTH_DATE = "02/42/2002";
  private final String GENDER = "Male";
  private final String MINUS_GENDER = "female";
  private final String UP_GENDER = "OTHER";
  private final String WRONG_GENDER = "WhalE";
  private final String EMAIL = "test@hotmail.com";
  private final String WRONG_EMAIL = "test@hotmail";
  private final String PASSWORD = "test";
  private final String ACCESS_TOKEN = "8a2e85eb-b7ab-411b-997f-7f4217d13100";
  private final String WRONG_ACCESS_TOKEN = "SalutC'estPatrick";
  private final String BLANK = "";

  @Test
  void givenValidRegisterDtoWhenVerifyRegisterDtoThenDoNothing() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE, GENDER);

    assertDoesNotThrow(() -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithTooLongNameWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(TOO_LONG_NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankNameWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(BLANK, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullNameWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(null, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithTooLongIdulWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, TOO_LONG_IDUL, AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankIdulWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, BLANK, AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullIdulWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, null, AGE, PASSWORD, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNegativeAgeWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, NEGATIVE_AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithOverAgeWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, OVER_AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithWrongBirthDateWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, WRONG_BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankBirthDateWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BLANK, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullBirthDateWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, null, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenValidRegisterDtoWithMinusGenderWhenVerifyRegisterDtoThenDoNothing() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        MINUS_GENDER);

    assertDoesNotThrow(() -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenValidRegisterDtoWithUpperGenderWhenVerifyRegisterDtoThenDoNothing() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        UP_GENDER);

    assertDoesNotThrow(() -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithWrongGenderWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        WRONG_GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankGenderWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE, BLANK);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullGenderWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE, null);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithWrongEmailWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, WRONG_EMAIL, IDUL, AGE, PASSWORD, BIRTH_DATE,
        GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankEmailWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, BLANK, IDUL, AGE, PASSWORD, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullEmailWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, null, IDUL, AGE, PASSWORD, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithBlankPasswordWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, BLANK, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenRegisterDtoWithNullPasswordWhenVerifyRegisterDtoThenThrowInvalidUserParameterException() {
    RegisterDto registerDto = new RegisterDto(NAME, EMAIL, IDUL, AGE, null, BIRTH_DATE, GENDER);

    assertThrows(BadRequestException.class, () -> {
      VALIDATOR.validRegisterDTO(registerDto);
    });
  }

  @Test
  void givenValidLoginDtoWhenVerifyLoginDtoThenDoNothing() {
    LoginDto loginDto = new LoginDto(EMAIL, PASSWORD);

    assertDoesNotThrow(() -> {
      VALIDATOR.validLoginDTO(loginDto);
    });
  }
}
