package ca.ulaval.glo4003.sulvlo.api.truck;

import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.TruckDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesDto;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("api/trucks")
public interface TruckResource {

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @RolesAllowed({"TECHNICIEN"})
  List<TruckDto> listTrucks(@HeaderParam("user-idul") String userIdul);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("{truck-id}:load")
  @RolesAllowed({"TECHNICIEN"})
  Response loadBikes(@HeaderParam("user-idul") String userIdul,
      @PathParam("truck-id") String truckId, LoadBikesDto loadBikesDto);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("{truck-id}:unload")
  @RolesAllowed({"TECHNICIEN"})
  Response unloadBikes(@HeaderParam("user-idul") String userIdul,
      @PathParam("truck-id") String truckId, UnloadBikesDto unloadBikesDto);
}
