package ca.ulaval.glo4003.sulvlo.api.payment.dto;

public record AutomaticBillingDto(
    boolean automaticBilling
) {

}
