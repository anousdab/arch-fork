package ca.ulaval.glo4003.sulvlo.domain.bike;

import ca.ulaval.glo4003.sulvlo.api.station.dto.BikesAvailabilitiesDto;

// TODO: ca en vrai jme demande si c pas mieux de juste le add dans BikeAssembler
public class BikesAvailabilitiesAssembler {

  public BikesAvailabilitiesDto create(int numberOfAvailableBikes, int numberOfTakenBikes) {
    return new BikesAvailabilitiesDto(numberOfAvailableBikes, numberOfTakenBikes);
  }

}
