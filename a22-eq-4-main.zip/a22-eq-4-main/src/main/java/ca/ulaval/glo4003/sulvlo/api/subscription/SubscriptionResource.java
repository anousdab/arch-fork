package ca.ulaval.glo4003.sulvlo.api.subscription;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/subscriptions")
public interface SubscriptionResource {

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  Response addSubscription(SubscriptionDto subscriptionDto);

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @PermitAll
  Response getSubscriptions();
}
