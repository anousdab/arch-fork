package ca.ulaval.glo4003.sulvlo.api.truck.dto;


import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesDto.UnloadBikeData;
import java.util.List;

public class UnloadBikesRequest {

  private String userIdul;
  private String truckId;
  private UnloadBikesDto unloadBikesDto;

  private UnloadBikesRequest(String userIdul, String truckId, UnloadBikesDto unloadBikesDto) {
    this.userIdul = userIdul;
    this.truckId = truckId;
    this.unloadBikesDto = unloadBikesDto;
  }

  public UnloadBikesRequest() {
  }

  public UnloadBikesRequest create(String userIdul, String truckId, UnloadBikesDto unloadBikesDto) {
    return new UnloadBikesRequest(userIdul, truckId, unloadBikesDto);
  }

  public String userIdul() {
    return userIdul;
  }

  public String truckId() {
    return truckId;
  }

  public List<UnloadBikeData> unloadBikeDataList() {
    return unloadBikesDto.unloadBikeDataList();
  }

}
