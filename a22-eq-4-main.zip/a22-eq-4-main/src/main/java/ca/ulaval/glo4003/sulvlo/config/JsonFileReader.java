package ca.ulaval.glo4003.sulvlo.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class JsonFileReader implements FileReader {

  @Override
  public List<FileStationDto> read(String path) {
    List<FileStationDto> fileStationDtoList = null;
    try {
      ObjectMapper mapper = new ObjectMapper();
      fileStationDtoList =
          Arrays.asList(mapper.readValue(Paths.get(path).toFile(), FileStationDto[].class));
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return fileStationDtoList;
  }
}
