package ca.ulaval.glo4003.sulvlo.domain.user;

import ca.ulaval.glo4003.sulvlo.api.user.dto.ActivationDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginTokenDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RequestMaintenanceDto;
import ca.ulaval.glo4003.sulvlo.auth.jwt.TokenAuthentificationDetails;
import ca.ulaval.glo4003.sulvlo.auth.jwt.TokenAuthentificationService;
import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.station.StationRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.exception.InvalidActivationTokenException;
import ca.ulaval.glo4003.sulvlo.domain.user.token.LoginTokenAssembler;
import ca.ulaval.glo4003.sulvlo.domain.user.token.UnlockBikeToken;
import ca.ulaval.glo4003.sulvlo.domain.user.token.UnlockBikeTokenFactory;
import ca.ulaval.glo4003.sulvlo.domain.util.DateUtils;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import ca.ulaval.glo4003.sulvlo.infrastructure.user.exception.UserAlreadyExistsException;
import jakarta.ws.rs.NotAuthorizedException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserService {

  private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

  private static final String ERROR_MESSAGE = "You cannot do this action.";
  private static final String ACTIVATION_TOKEN_EMAIL_SUBJECT = "Activation account token for SULVLO";
  private static final String UNIQUE_CODE_EMAIL_SUBJECT = "Unique bike code for SULVLO";
  private static final String REQUEST_MAINTENANCE_EMAIL_SUBJECT = "Request maintenance for SULVLO";

  private final UserRepository userRepository;
  private final StationRepository stationRepository;
  private final UserFactory userFactory;
  private final LoginTokenAssembler loginTokenAssembler;
  private final EmailSender emailSender;
  private final UnlockBikeTokenFactory unlockBikeTokenFactory;
  private final TokenAuthentificationService tokenAuthentificationService;

  public UserService(UserRepository userRepository, StationRepository stationRepository,
      EmailSender emailSender) {
    this.emailSender = emailSender;
    this.userRepository = userRepository;
    this.stationRepository = stationRepository;
    this.userFactory = new UserFactory();
    this.loginTokenAssembler = new LoginTokenAssembler();
    this.unlockBikeTokenFactory = new UnlockBikeTokenFactory();
    this.tokenAuthentificationService = new TokenAuthentificationService();
  }

  public UUID register(RegisterDto info) throws UserAlreadyExistsException {
    LOGGER.info("Register user {}", info);
    User user = userFactory.create(info);
    userRepository.save(user);
    String emailBody = formatEmailBodyForActivationCode(user.getActivationToken());
    emailSender.send(user.getEmail(), emailBody, ACTIVATION_TOKEN_EMAIL_SUBJECT);
    return user.getId();
  }

  public LoginTokenDto login(LoginDto info) throws NotAuthorizedException {
    LOGGER.info("Login user {}", info);
    User user = findUserByEmail(info.email());
    user.checkPassword(info.password().hashCode());

    TokenAuthentificationDetails tokenAuthentificationDetails = tokenAuthentificationService
        .createJwtTokenDetails(user.getName(), user.getEmail(), user.getIdul(),
            getRoleOfCurrentUser(user.getEmail()));
    String token = tokenAuthentificationService.createJwtToken(tokenAuthentificationDetails);

    LocalDateTime expirationDate = DateUtils
        .convertDateToLocalDateTime(tokenAuthentificationService.getClaims(token).getExpiration());
    return loginTokenAssembler.create(token, expirationDate);
  }

  public void activateUser(String userToken, ActivationDto activationDto) {
    LOGGER.info("Activate user account {}", activationDto);
    String email = activationDto.email();
    User user = findUserByEmail(email);
    user.validateActivationToken(userToken);
  }

  public void sendUniqueCodeToUnlockBike(String email) throws InvalidActivationTokenException {
    LOGGER.info("Sending unlock bike unique code to {}", email);
    User user = findUserByEmail(email);
    if (!user.isAccountVerified() || user.isBlocked()) {
      throw new NotAuthorizedException(ERROR_MESSAGE);
    }

    String randomUniqueCode = generateRandomUniqueCode();
    UnlockBikeToken unlockBikeToken = unlockBikeTokenFactory.create(randomUniqueCode);
    user.setUnlockBikeToken(unlockBikeToken);
    // TODO: Same as the activation code, think of a way to do this without printing
    // the value but still be able to get it without
    // verifying email for the e2e tests to work. In this case we cant put it in the
    // response header so maybe put the
    // generateRandomUniqueCode() function in the UserResourceImpl class and pass
    // the randomUniqueCode
    // unto this function so that we can put the value in the response header. Other
    // solutions are very welcome...
    System.out.println(unlockBikeToken.getCode());
    // TODO : ADD bike location to ActivationDto
    emailSender.send(email, formatEmailBodyForUnlockBikeCode(randomUniqueCode),
        UNIQUE_CODE_EMAIL_SUBJECT);
  }

  private String generateRandomUniqueCode() {
    return RandomStringUtils.randomNumeric(10);
  }

  private String formatEmailBodyForActivationCode(String token) {
    return String.format(
        "Your activation token is: %s, please enter this token to validate your account!", token);
  }

  private String formatEmailBodyForUnlockBikeCode(String code) {
    return String.format("Your unique code to unlock your bike is: %s", code);
  }

  public User findUserByEmail(String email) {
    return userRepository.getByEmail(email);
  }

  public String getRoleOfCurrentUser(String email) {
    User user = findUserByEmail(email);
    return user.getUserType().toString();
  }

  private String formatEmailBodyForRequestMaintenance(String code) {
    return String.format("Station '%s' needs G.", code);
  }

  public void sendMaintenanceRequest(RequestMaintenanceDto requestMaintenanceDto) {
    LOGGER.info("Sending maintenance requests {}", requestMaintenanceDto);
    User user = userRepository.getByEmail(requestMaintenanceDto.email());
    Station station = stationRepository.findAvailableByCode(requestMaintenanceDto.stationCode());
    List<User> listTechnicien = userRepository.getUsersByType(UserType.TECHNICIEN);
    listTechnicien.forEach(users -> {
      emailSender.send(users.getEmail(),
          formatEmailBodyForRequestMaintenance(requestMaintenanceDto.stationCode()),
          REQUEST_MAINTENANCE_EMAIL_SUBJECT);
    });
  }

}
