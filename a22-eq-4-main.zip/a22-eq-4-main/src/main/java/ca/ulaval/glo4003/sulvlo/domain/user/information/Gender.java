package ca.ulaval.glo4003.sulvlo.domain.user.information;

public enum Gender {
  MALE,
  FEMALE,
  OTHER
}
