package ca.ulaval.glo4003.sulvlo.api.payment;

import ca.ulaval.glo4003.sulvlo.api.payment.dto.AutomaticBillingDto;
import ca.ulaval.glo4003.sulvlo.api.payment.dto.CreditCardDto;
import ca.ulaval.glo4003.sulvlo.api.payment.dto.SaveCreditCardDto;
import jakarta.annotation.security.PermitAll;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/payment")
public interface PaymentResource {

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("set-automatic-payment")
  @PermitAll
  Response addAutomaticBilling(@HeaderParam("idul") String idul,
      AutomaticBillingDto automaticBillingDto);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("pay-extra-fees")
  @PermitAll
  Response payExtraFees(@HeaderParam("idul") String idul);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("pay-debt")
  @PermitAll
  Response payDebt(@HeaderParam("idul") String idul);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("save-credit-card")
  @PermitAll
  Response saveCreditCard(@HeaderParam("idul") String idul, SaveCreditCardDto creditCardDto);
}
