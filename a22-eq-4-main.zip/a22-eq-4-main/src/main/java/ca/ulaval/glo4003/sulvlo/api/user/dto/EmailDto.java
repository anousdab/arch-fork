package ca.ulaval.glo4003.sulvlo.api.user.dto;

public interface EmailDto {

  String email();

}
