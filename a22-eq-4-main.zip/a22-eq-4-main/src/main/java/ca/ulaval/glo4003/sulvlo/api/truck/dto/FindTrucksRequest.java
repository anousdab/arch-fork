package ca.ulaval.glo4003.sulvlo.api.truck.dto;

public class FindTrucksRequest {

  private String userIdul;

  private FindTrucksRequest(String userIdul) {
    this.userIdul = userIdul;
  }

  public FindTrucksRequest() {

  }

  public FindTrucksRequest create(String userIdul) {
    return new FindTrucksRequest(userIdul);
  }

  public String userIdul() {
    return userIdul;
  }

}
