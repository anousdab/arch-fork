package ca.ulaval.glo4003.sulvlo.api.bike.dto;

public record BikeDto(int location, String energyLevel, String status) {

}
