package ca.ulaval.glo4003.sulvlo.api.payment.dto;

public record SaveCreditCardDto (
    String creditCardNumber,
    int expirationMonth,
    int expirationYear,
    int ccv
    ) implements CreditCardDto{

}
