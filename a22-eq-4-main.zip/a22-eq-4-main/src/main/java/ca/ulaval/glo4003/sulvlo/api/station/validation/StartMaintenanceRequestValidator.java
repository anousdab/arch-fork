package ca.ulaval.glo4003.sulvlo.api.station.validation;

import ca.ulaval.glo4003.sulvlo.api.station.dto.StartMaintenanceRequest;

public class StartMaintenanceRequestValidator {

  private final CommonStationRequestsValidators commonStationRequestsValidators;

  public StartMaintenanceRequestValidator(
      CommonStationRequestsValidators commonStationRequestsValidators) {
    this.commonStationRequestsValidators = commonStationRequestsValidators;
  }

  public void validate(StartMaintenanceRequest startMaintenanceRequest) {
    commonStationRequestsValidators.validateStationCode(startMaintenanceRequest.stationCode());
    commonStationRequestsValidators.validateUserIdul(startMaintenanceRequest.userIdul());
  }

}
