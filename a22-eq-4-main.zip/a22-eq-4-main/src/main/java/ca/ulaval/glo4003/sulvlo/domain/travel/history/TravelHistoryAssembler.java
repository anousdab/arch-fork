package ca.ulaval.glo4003.sulvlo.domain.travel.history;

import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelHistorySummaryDTO;

public class TravelHistoryAssembler {

  public TravelHistorySummaryDTO create(TravelHistorySummary travelHistorySummary) {
    return new TravelHistorySummaryDTO(
        travelHistorySummary.totalTravelsTime(),
        travelHistorySummary.averageTravelTime(),
        travelHistorySummary.numberOfTravels(),
        travelHistorySummary.favoriteStation());
  }
}
