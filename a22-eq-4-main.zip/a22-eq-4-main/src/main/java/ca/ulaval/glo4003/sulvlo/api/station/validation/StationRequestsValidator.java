package ca.ulaval.glo4003.sulvlo.api.station.validation;

import ca.ulaval.glo4003.sulvlo.api.station.dto.StopMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StartMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;

public class StationRequestsValidator {
  private final UnlockBikeRequestValidator unlockBikeRequestValidator;
  private final ReturnBikeRequestValidator returnBikeRequestValidator;
  private final StartMaintenanceRequestValidator startMaintenanceRequestValidator;
  private final ResumeServiceRequestValidator resumeServiceRequestValidator;

  public StationRequestsValidator(
      UnlockBikeRequestValidator unlockBikeRequestValidator,
      ReturnBikeRequestValidator returnBikeRequestValidator,
      StartMaintenanceRequestValidator startMaintenanceRequestValidator,
      ResumeServiceRequestValidator resumeServiceRequestValidator) {
    this.unlockBikeRequestValidator = unlockBikeRequestValidator;
    this.returnBikeRequestValidator = returnBikeRequestValidator;
    this.startMaintenanceRequestValidator = startMaintenanceRequestValidator;
    this.resumeServiceRequestValidator = resumeServiceRequestValidator;
  }

  public void validateUnlockBikeRequest(UnlockBikeRequest unlockBikeRequest) {
    unlockBikeRequestValidator.validate(unlockBikeRequest);
  }

  public void validateReturnBikeRequest(ReturnBikeRequest returnBikeRequest) {
    returnBikeRequestValidator.validate(returnBikeRequest);
  }

  public void validateStartMaintenanceRequest(StartMaintenanceRequest startMaintenanceRequest) {
    startMaintenanceRequestValidator.validate(startMaintenanceRequest);
  }

  public void validateResumeServiceRequest(StopMaintenanceRequest stopMaintenanceRequest) {
    resumeServiceRequestValidator.validate(stopMaintenanceRequest);
  }

}
