package ca.ulaval.glo4003.sulvlo.domain.payment.cron;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;

public class PayMonthlyJob implements Job {
    @Override
    public void execute(JobExecutionContext context)
            throws JobExecutionException {
        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        PaymentService paymentService = (PaymentService) dataMap.get("paymentService");
        paymentService.automaticPayExtraFeesUsers();
    }
}
