package ca.ulaval.glo4003.sulvlo.api.validation;


import ca.ulaval.glo4003.sulvlo.api.payment.dto.SaveCreditCardDto;
import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.CreditCard.CCardCcvValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.CreditCard.CCardExpirationValidator;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.CreditCard.CCardNumberValidator;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.EmailValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.PasswordValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register.AgeValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register.BirthDateValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register.GenderValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register.IdulValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register.UserNameValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Subscription.SemesterValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Subscription.SubscriptionTypeValidation;
import ca.ulaval.glo4003.sulvlo.api.validation.exception.InvalidConnectionArgumentException;
import ca.ulaval.glo4003.sulvlo.api.validation.exception.InvalidPaymentParameterException;
import ca.ulaval.glo4003.sulvlo.api.validation.exception.InvalidSubscriptionParameterException;

public class ValidatorMediator {

  private final ValidationNode<RegisterDto> registerValidationChain = ValidationNode.link(
      new UserNameValidation(),
      new IdulValidation(),
      new AgeValidation(),
      new EmailValidation(),
      new PasswordValidation(),
      new BirthDateValidation(),
      new GenderValidation());

  private final ValidationNode<LoginDto> loginValidationChain = ValidationNode.link(
      new EmailValidation(),
      new PasswordValidation());

  private final ValidationNode<SubscriptionDto> subscriptionValidationChain = ValidationNode.link(
      new EmailValidation(),
      new SemesterValidation(),
      new SubscriptionTypeValidation());

  private final ValidationNode<SubscriptionDto> creditCardValidationChain = ValidationNode.link(
      new CCardNumberValidator(),
      new CCardExpirationValidator(),
      new CCardCcvValidation());

  private final ValidationNode<SaveCreditCardDto> creditCardSaveValidationChain = ValidationNode.link(
      new CCardNumberValidator(),
      new CCardExpirationValidator(),
      new CCardCcvValidation());


  public void validRegisterDTO(RegisterDto dto) throws InvalidConnectionArgumentException {
    if (!registerValidationChain.isValid(dto)) {
      throw new InvalidConnectionArgumentException();
    }
  }

  public void validLoginDTO(LoginDto dto) {
    if (!loginValidationChain.isValid(dto)) {
      throw new InvalidConnectionArgumentException();
    }
  }

  public void validSubscription(SubscriptionDto dto) throws InvalidSubscriptionParameterException {
    if (!subscriptionValidationChain.isValid(dto)) {
      throw new InvalidSubscriptionParameterException();
    }
  }

  public void validCreditCard(SubscriptionDto dto) throws InvalidSubscriptionParameterException {
    if (!creditCardValidationChain.isValid(dto)) {
      throw new InvalidSubscriptionParameterException();
    }
  }

  public void validSaveCreditCard(SaveCreditCardDto dto) throws InvalidPaymentParameterException {
    if (!creditCardSaveValidationChain.isValid(dto)) {
      throw new InvalidPaymentParameterException();
    }
  }



}
