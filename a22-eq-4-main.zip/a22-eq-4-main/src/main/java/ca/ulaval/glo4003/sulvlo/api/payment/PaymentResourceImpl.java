package ca.ulaval.glo4003.sulvlo.api.payment;

import ca.ulaval.glo4003.sulvlo.api.payment.dto.AutomaticBillingDto;
import ca.ulaval.glo4003.sulvlo.api.payment.dto.SaveCreditCardDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;
import jakarta.ws.rs.core.Response;

public class PaymentResourceImpl implements PaymentResource {


  PaymentService paymentService;
  private final ValidatorMediator validator = new ValidatorMediator();

  public PaymentResourceImpl(PaymentService paymentService) {
    this.paymentService = paymentService;
  }

  @Override
  public Response addAutomaticBilling(String idul, AutomaticBillingDto automaticBillingDto) {
    paymentService.addAutomaticBiling(idul, automaticBillingDto);
    return Response.ok().build();
  }

  @Override
  public Response payExtraFees(String idul) {
    paymentService.payExtraFees(idul);
    return Response.ok().build();
  }

  @Override
  public Response payDebt(String idul) {
    paymentService.payDebt(idul);
    return Response.ok().build();
  }

  @Override
  public Response saveCreditCard(String idul, SaveCreditCardDto creditCardDto) {
    validator.validSaveCreditCard(creditCardDto);
    paymentService.saveCreditCard(idul, creditCardDto);
    return Response.ok().build();
  }
}
