package ca.ulaval.glo4003.sulvlo.api.station.validation;

import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;

public class UnlockBikeRequestValidator {

  private final CommonStationRequestsValidators commonStationRequestsValidators;

  public UnlockBikeRequestValidator(
      CommonStationRequestsValidators commonStationRequestsValidators) {
    this.commonStationRequestsValidators = commonStationRequestsValidators;
  }

  public void validate(UnlockBikeRequest unlockBikeRequest) {
    commonStationRequestsValidators.validateUserCode(unlockBikeRequest.userCode());
    commonStationRequestsValidators.validateStationCode(unlockBikeRequest.stationCode());
    commonStationRequestsValidators.validateBikeLocation(unlockBikeRequest.bikeLocation());
  }
}
