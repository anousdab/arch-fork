package ca.ulaval.glo4003.sulvlo.api.travel;

import ca.ulaval.glo4003.sulvlo.domain.travel.TravelService;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;
import java.time.Month;


public class TravelResourceImpl implements TravelResource {

  private final String ERROR_MESSAGE = "You have entered one or more invalid field, please try again!";
  private final TravelService travelService;

  public TravelResourceImpl(TravelService travelService) {
    this.travelService = travelService;
  }

  @Override
  public Response getAllTravelsByMonth(String month, @NotNull String userId) {
    convertStringToMonth(month.toUpperCase());
    if (userId.isBlank()) {
      return Response.status(Response.Status.BAD_REQUEST).build();
    }
    return Response.status(Response.Status.OK)
        .entity(travelService.getAllTravelsFilteredByMonth(month, userId)).build();
  }

  @Override
  public Response getAllTravels() {
    return Response.status(Response.Status.OK)
        .entity(travelService.getAllTravels())
        .build();
  }

  private boolean convertStringToMonth(String month) {
    try {
      Month.valueOf(month);
    } catch (Exception e) {
      throw new BadRequestException(ERROR_MESSAGE);
    }
    return true;
  }

  @Override
  public Response getTravelById(String id) throws InvalidTravelIdException {
    return Response.status(Response.Status.OK).entity(travelService.getTravelById(id)).build();
  }

  @Override
  public Response getTravelHistorySummary(String userId) {
    return Response.status(Response.Status.OK).entity(travelService.getTravelHistorySummary(userId))
        .build();
  }
}

