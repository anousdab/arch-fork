package ca.ulaval.glo4003.sulvlo.domain.user;

import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;
import ca.ulaval.glo4003.sulvlo.domain.user.exception.InvalidActivationTokenException;
import ca.ulaval.glo4003.sulvlo.domain.user.exception.UserConnectionException;
import ca.ulaval.glo4003.sulvlo.domain.user.information.Gender;
import ca.ulaval.glo4003.sulvlo.domain.user.information.UserInformation;
import ca.ulaval.glo4003.sulvlo.domain.user.token.UnlockBikeToken;
import java.time.LocalDateTime;
import java.util.UUID;

public class User {

  private final UserInformation userInformation;
  private BankAccount bankAccount;
  private final String activationToken;
  private boolean accountVerified;
  private UnlockBikeToken unlockBikeToken;
  private boolean isBlocked;
  private final UserType userType;

  public User(UserInformation userInformation, BankAccount bankAccount, UserType userType) {
    this.userInformation = userInformation;
    this.userType = userType;
    this.bankAccount = bankAccount;
    this.activationToken = createActivationToken(userInformation.userId());
    this.accountVerified = false;
    this.isBlocked = true;
    this.unlockBikeToken = UnlockBikeToken.NULL;
  }

  public boolean isTechnicien() {
    return userType.equals(UserType.TECHNICIEN);
  }

  public void checkPassword(int hashedPassword) {
    if (this.userInformation.password() != hashedPassword) {
      throw new UserConnectionException();
    }
  }


  public UUID getId() {
    return this.userInformation.userId();
  }

  public String getIdul() {
    return this.userInformation.idul();
  }

  public String getName() {
    return this.userInformation.name();
  }

  public String getEmail() {
    return this.userInformation.email();
  }

  public Gender getGender() {
    return this.userInformation.gender();
  }

  public BankAccount getBankAccount() {
    return this.bankAccount;
  }

  public void setBankAccount(BankAccount bankAccount) {
    this.bankAccount = bankAccount;
  }

  public boolean isBlocked() {
    return this.isBlocked;
  }

  public void blockAccount() {
    this.isBlocked = false;
  }

  public void unblockAccount() {
    this.isBlocked = false;
  }

  public void validateActivationToken(String token) {
    if (this.activationToken.equals(token)) {
      this.accountVerified = true;
      return;
    }
    throw new InvalidActivationTokenException();
  }

  public String getActivationToken() {
    return this.activationToken;
  }

  public boolean isAccountVerified() {
    return accountVerified;
  }

  public String createActivationToken(UUID userId) {
    return Integer.toString(userId.toString().hashCode());
  }

  public boolean validateUnlockBikeToken(String validationToken) {
    return this.unlockBikeToken.validateTokenIsActif(validationToken, LocalDateTime.now());
  }

  public void setUnlockBikeToken(UnlockBikeToken unlockBikeToken) {
    this.unlockBikeToken = unlockBikeToken;
  }

  public UnlockBikeToken getUnlockBikeToken() {
    return unlockBikeToken;
  }

  public UserType getUserType() {
    return userType;
  }

  public String getUserIdul() {
    return userInformation.idul();
  }

  public void setAccountVerified(boolean accountVerified) {
    this.accountVerified = accountVerified;
  }
}