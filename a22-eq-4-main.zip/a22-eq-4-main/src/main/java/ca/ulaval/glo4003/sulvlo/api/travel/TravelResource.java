package ca.ulaval.glo4003.sulvlo.api.travel;

import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import jakarta.annotation.security.PermitAll;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/travel")
public interface TravelResource {

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @PermitAll
  Response getAllTravelsByMonth(@HeaderParam("month") String session,
      @HeaderParam("userId") @NotNull String userId);

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/all")
  @PermitAll
  Response getAllTravels();


  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("{id}")
  @PermitAll
  Response getTravelById(@PathParam("id") String id) throws InvalidTravelIdException;

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/summary")
  @PermitAll
  Response getTravelHistorySummary(@HeaderParam("userId") String userId) throws Exception;
}
