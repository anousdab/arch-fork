package ca.ulaval.glo4003.sulvlo.infrastructure.subscription.type;

import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionType;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeRepository;
import com.google.common.collect.Lists;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SubscriptionTypeRepositoryInMemory implements SubscriptionTypeRepository {

  private final Map<String, SubscriptionType> subscriptionTypes = new HashMap<>();

  public SubscriptionTypeRepositoryInMemory() {
    SubscriptionTypeDevDataFactory subscriptionTypeDevDataFactory =
        new SubscriptionTypeDevDataFactory();
    List<SubscriptionType> subscriptionTypeList = subscriptionTypeDevDataFactory.createMockData();
    subscriptionTypeList.stream().forEach(subscriptionType -> save(subscriptionType));
  }

  @Override
  public List<SubscriptionType> findAll() {
    return Lists.newArrayList(subscriptionTypes.values());
  }

  @Override
  public SubscriptionType findByName(String subscriptionType) {
    return subscriptionTypes.get(subscriptionType);
  }

  @Override
  public void save(SubscriptionType subscriptionType) {
    subscriptionTypes.put(subscriptionType.type(), subscriptionType);
  }
}
