package ca.ulaval.glo4003.sulvlo.api.station.dto;

public record BikesAvailabilitiesDto(int numberOfAvailableBikes, int numberOfTakenBikes) {

}
