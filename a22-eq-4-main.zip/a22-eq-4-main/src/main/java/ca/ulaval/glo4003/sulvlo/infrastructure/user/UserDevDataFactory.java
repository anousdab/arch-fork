package ca.ulaval.glo4003.sulvlo.infrastructure.user;

import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserType;
import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;
import ca.ulaval.glo4003.sulvlo.domain.user.information.Gender;
import ca.ulaval.glo4003.sulvlo.domain.user.information.UserInformation;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class UserDevDataFactory {

  private static final UserInformation TECHNICIEN_USER_INFO = new UserInformation("Sylvain",
      "technicien@nospam.today", "SYGAU1", 25, LocalDate.of(1997, 06, 03), Gender.MALE,
      UUID.randomUUID(), "test123".hashCode());

  private static final UserInformation NORMAL_USER_INFO = new UserInformation("Martin",
      "martin@nospam.today", "MAGAU1", 22, LocalDate.of(2000, 06, 03), Gender.MALE, UUID.randomUUID(),
      "test123".hashCode());

  private static final UserInformation ADMIN_USER_INFO = new UserInformation("Anabelle",
      "ROTHSCHILD@nospam.today", "LOLOL777", 22, LocalDate.of(2000, 06, 03), Gender.MALE, UUID.randomUUID(),
      "test123".hashCode());

  public List<User> createMockData() {
    BankAccount bankAccount = new BankAccount();
    User norm = new User(NORMAL_USER_INFO, bankAccount, UserType.NORMAL);
    User tech = new User(TECHNICIEN_USER_INFO, bankAccount, UserType.TECHNICIEN);
    User admin = new User(ADMIN_USER_INFO, bankAccount, UserType.MANAGER);
    tech.setAccountVerified(true);
    tech.unblockAccount();
    return List.of(norm, tech, admin);
  }

}
