package ca.ulaval.glo4003.sulvlo.api.station;

import ca.ulaval.glo4003.sulvlo.api.station.dto.BikesAvailabilitiesDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationDto;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("api/stations")
public interface StationResource {

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("available")
  List<StationDto> listAvailableStations();

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("under-maintenance")
  @RolesAllowed({"TECHNICIEN"})
  List<StationDto> listUnderMaintenanceStations();

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("available-bikes")
  @RolesAllowed({"MANAGER"})
  BikesAvailabilitiesDto listAllBikesAvailabilities();

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Path("available/{station-code}/bikes/{bike-location}:unlock")
  Response unlockBike(@HeaderParam("user-code") String userCode,
      @PathParam("station-code") String stationCode,
      @PathParam("bike-location") String bikeLocation);

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("available/{return-station-code}/bikes/{return-bike-location}:return")
  Response returnBike(@HeaderParam("unlock-station-code") String unlockStationCode,
      @HeaderParam("unlock-bike-location") String unlockBikeLocation,
      @PathParam("return-station-code") String returnStationCode,
      @PathParam("return-bike-location") String returnBikeLocation);

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Path("under-maintenance/{station-code}:start-maintenance")
  @RolesAllowed({"TECHNICIEN"})
  Response startMaintenance(@HeaderParam("user-idul") String userIdul,
      @PathParam("station-code") String stationCode);


  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @RolesAllowed({"TECHNICIEN"})
  @Path("under-maintenance/{station-code}:end-maintenance")
  Response endMaintenance(@HeaderParam("user-idul") String userIdul,
      @PathParam("station-code") String stationCode);

}
