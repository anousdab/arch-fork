package ca.ulaval.glo4003.sulvlo.domain.user.bank;

import java.math.BigDecimal;

import com.google.common.base.Objects;

public class Balance {

  public BigDecimal balance;
  public static final Balance ZERO = new Balance(BigDecimal.ZERO);

  public Balance(BigDecimal amount) {
    balance = amount;
  }

  public void add(BigDecimal amount) {
    balance.add(amount);
  }

  public void sub(BigDecimal amount) {
    balance.subtract(amount);
  }

  public BigDecimal amount() {
    return balance;
  }

  public boolean empty() {
    return balance.compareTo(BigDecimal.ZERO) == 0;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Balance that = (Balance) o;
    return Objects.equal(balance, that.balance);
  }

}
