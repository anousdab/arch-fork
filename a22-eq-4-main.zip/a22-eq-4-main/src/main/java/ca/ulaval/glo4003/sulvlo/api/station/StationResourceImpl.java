package ca.ulaval.glo4003.sulvlo.api.station;


import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.station.dto.BikesAvailabilitiesDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StartMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationRequestsCreator;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StopMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.validation.StationRequestsValidator;
import ca.ulaval.glo4003.sulvlo.domain.station.StationService;
import jakarta.ws.rs.core.Response;
import java.util.List;

public class StationResourceImpl implements StationResource {

  private static final String SUCCESSFULLY_UNLOCKED_MSG = "The bike was successfully unlocked.";
  private static final String SUCCESSFULLY_RETURNED_MSG = "The bike was successfully returned.";
  private static final String SUCCESSFULLY_START_MAINTENANCE_MSG = "The station is now under maintenance.";
  private static final String SUCCESSFULLY_RESUME_SERVICE_MSG = "The station is now available.";

  private final StationService stationService;
  private final StationRequestsValidator stationRequestsValidator;
  private final SuccessfulResponse successfulResponse;
  private final StationRequestsCreator stationRequestsCreator;

  public StationResourceImpl(StationService stationService,
      StationRequestsValidator stationRequestsValidator, SuccessfulResponse successfulResponse,
      StationRequestsCreator stationRequestsCreator) {
    this.stationService = stationService;
    this.stationRequestsValidator = stationRequestsValidator;
    this.successfulResponse = successfulResponse;
    this.stationRequestsCreator = stationRequestsCreator;
  }

  @Override
  public List<StationDto> listAvailableStations() {
    return stationService.findAllAvailableStations();
  }

  @Override
  public List<StationDto> listUnderMaintenanceStations() {
    return stationService.findAllUnderMaintenanceStations();
  }

  @Override
  public BikesAvailabilitiesDto listAllBikesAvailabilities() {
    return stationService.findAllBikesAvailabilities();
  }

  @Override
  public Response unlockBike(String userCode, String stationCode, String bikeLocation) {
    UnlockBikeRequest unlockBikeRequest = stationRequestsCreator.createUnlockBikeRequest(userCode,
        stationCode, bikeLocation);
    stationRequestsValidator.validateUnlockBikeRequest(unlockBikeRequest);
    stationService.unlockBike(unlockBikeRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_UNLOCKED_MSG).toString()).build();
  }

  @Override
  public Response returnBike(String unlockStationCode, String unlockBikeLocation,
      String returnStationCode, String returnBikeLocation) {
    ReturnBikeRequest returnBikeRequest = stationRequestsCreator.createReturnBikeRequest(
        unlockStationCode, unlockBikeLocation, returnStationCode, returnBikeLocation);
    stationRequestsValidator.validateReturnBikeRequest(returnBikeRequest);
    stationService.returnBike(returnBikeRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_RETURNED_MSG).toString()).build();
  }

  @Override
  public Response startMaintenance(String userIdul, String stationCode) {
    StartMaintenanceRequest startMaintenanceRequest = stationRequestsCreator.createStartMaintenanceRequest(
        userIdul, stationCode);
    stationRequestsValidator.validateStartMaintenanceRequest(startMaintenanceRequest);
    stationService.startMaintenance(startMaintenanceRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_START_MAINTENANCE_MSG).toString()).build();
  }

  @Override
  public Response endMaintenance(String userIdul, String stationCode) {
    StopMaintenanceRequest stopMaintenanceRequest = stationRequestsCreator.createStopMaintenanceRequest(
        userIdul, stationCode);
    stationRequestsValidator.validateResumeServiceRequest(stopMaintenanceRequest);
    stationService.endMaintenance(stopMaintenanceRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_RESUME_SERVICE_MSG).toString()).build();
  }

}
