package ca.ulaval.glo4003.sulvlo.domain.user;

public enum UserType {
  NORMAL, TECHNICIEN, MANAGER
}
