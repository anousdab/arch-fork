package ca.ulaval.glo4003.sulvlo.api.travel.dto;

public record TravelHistorySummaryDTO(String totalTravelsTime,
                                      String averageTravelTime,
                                      int numberOfTravels,
                                      String favoriteStation) {

}
