package ca.ulaval.glo4003.sulvlo.api.truck;

import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.FindTrucksRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.TruckDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.TruckRequestsCreator;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.TruckRequestsValidator;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckService;
import jakarta.ws.rs.core.Response;
import java.util.List;

public class TruckResourceImpl implements TruckResource {

  private static final String SUCCESSFULLY_LOAD_BIKES_MSG = "The bikes were successfully loaded.";
  private static final String SUCCESSFULLY_UNLOAD_BIKES_MSG = "The bikes were successfully unloaded.";

  private final TruckService truckService;
  private final TruckRequestsCreator truckRequestsCreator;
  private final TruckRequestsValidator truckRequestsValidator;
  private final SuccessfulResponse successfulResponse;

  public TruckResourceImpl(TruckService truckService, TruckRequestsCreator truckRequestsCreator,
      TruckRequestsValidator truckRequestsValidator, SuccessfulResponse successfulResponse) {
    this.truckService = truckService;
    this.truckRequestsCreator = truckRequestsCreator;
    this.truckRequestsValidator = truckRequestsValidator;
    this.successfulResponse = successfulResponse;
  }

  @Override
  public List<TruckDto> listTrucks(String userIdul) {
    FindTrucksRequest findTrucksRequest = truckRequestsCreator.createFindTrucksRequest(userIdul);
    truckRequestsValidator.validateFindTrucksRequest(findTrucksRequest);
    return truckService.findAllTrucks(findTrucksRequest);
  }

  @Override
  public Response loadBikes(String userIdul, String truckId, LoadBikesDto loadBikesDto) {
    LoadBikesRequest loadBikesRequest = truckRequestsCreator.createLoadBikesDtoRequest(userIdul,
        truckId, loadBikesDto);
    truckRequestsValidator.validateLoadBikesRequest(loadBikesRequest);
    truckService.loadBikes(loadBikesRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_LOAD_BIKES_MSG).toString()).build();
  }

  @Override
  public Response unloadBikes(String userIdul, String truckId, UnloadBikesDto unloadBikesDto) {
    UnloadBikesRequest unloadBikesRequest = truckRequestsCreator.createUnloadBikesRequest(userIdul,
        truckId, unloadBikesDto);
    truckRequestsValidator.validateUnloadBikesRequest(unloadBikesRequest);
    truckService.unload(unloadBikesRequest);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_UNLOAD_BIKES_MSG).toString()).build();
  }
}
