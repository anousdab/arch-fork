package ca.ulaval.glo4003.sulvlo.domain.util;


import java.util.concurrent.TimeUnit;

public final class TimeUtils {

  private static final String ERROR_MSG = "Utility class and cannot be instantiated";

  private TimeUtils() {
    throw new UnsupportedOperationException(ERROR_MSG);
  }

  public static double fromMillisecondsToMinutes(long milliseconds) {
    return TimeUnit.MILLISECONDS.toMinutes(milliseconds);
  }
}
