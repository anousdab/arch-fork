package ca.ulaval.glo4003.sulvlo.api.subscription.dto;

import ca.ulaval.glo4003.sulvlo.api.payment.dto.CreditCardDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.EmailDto;

public record SubscriptionDto(
    String subscriptionType,
    String semester,
    String email,
    String creditCardNumber,
    int expirationMonth,
    int expirationYear,
    int ccv,
    boolean savePayment,
    boolean immediatePayment

) implements EmailDto, CreditCardDto {

}
