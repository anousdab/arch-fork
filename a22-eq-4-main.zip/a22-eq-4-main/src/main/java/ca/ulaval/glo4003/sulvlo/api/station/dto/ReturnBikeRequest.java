package ca.ulaval.glo4003.sulvlo.api.station.dto;

public class ReturnBikeRequest {

  private String unlockStationCode;
  private String unlockBikeLocation;
  private String returnStationCode;
  private String returnBikeLocation;

  private ReturnBikeRequest(String unlockStationCode, String unlockBikeLocation,
      String returnStationCode, String returnBikeLocation) {
    this.unlockStationCode = unlockStationCode;
    this.unlockBikeLocation = unlockBikeLocation;
    this.returnStationCode = returnStationCode;
    this.returnBikeLocation = returnBikeLocation;
  }

  public ReturnBikeRequest() {}

  public ReturnBikeRequest create(String unlockStationCode, String unlockBikeLocation,
      String returnStationCode, String returnBikeLocation) {
    return new ReturnBikeRequest(unlockStationCode, unlockBikeLocation, returnStationCode,
        returnBikeLocation);
  }

  public String unlockStationCode() {
    return unlockStationCode;
  }

  public String unlockBikeLocation() {
    return unlockBikeLocation;
  }

  public String returnStationCode() {
    return returnStationCode;
  }

  public String returnBikeLocation() {
    return returnBikeLocation;
  }
}
