package ca.ulaval.glo4003.sulvlo.api.truck.validation;

import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesRequest;
import jakarta.ws.rs.BadRequestException;
import java.util.List;


public class LoadBikesRequestValidator {

  private static final String INVALID_BIKES_LOCATIONS_MSG = "Invalid bikesLocations";

  private final CommonTruckRequestsValidators commonTruckRequestsValidators;

  public LoadBikesRequestValidator(CommonTruckRequestsValidators commonTruckRequestsValidators) {
    this.commonTruckRequestsValidators = commonTruckRequestsValidators;
  }

  public void validate(LoadBikesRequest loadBikesRequest) {
    commonTruckRequestsValidators.commonStationRequestsValidators()
        .validateUserIdul(loadBikesRequest.userIdul());
    commonTruckRequestsValidators.validateTruckId(loadBikesRequest.truckId());
    commonTruckRequestsValidators.commonStationRequestsValidators()
        .validateStationCode(loadBikesRequest.fromStationCode());
    checkBikesLocationsNotEmpty(loadBikesRequest.bikesLocations());
    loadBikesRequest.bikesLocations().forEach(
        commonTruckRequestsValidators.commonStationRequestsValidators()::validateBikeLocation);
  }

  private void checkBikesLocationsNotEmpty(List<String> bikesLocations) {
    if (bikesLocations.isEmpty()) {
      throw new BadRequestException(INVALID_BIKES_LOCATIONS_MSG);
    }
  }

}
