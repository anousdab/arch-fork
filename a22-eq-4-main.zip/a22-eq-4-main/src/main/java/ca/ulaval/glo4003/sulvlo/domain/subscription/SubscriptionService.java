package ca.ulaval.glo4003.sulvlo.domain.subscription;

import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionTypeDto;
import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionType;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeRepository;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SubscriptionService {

  private static final Logger LOGGER = LoggerFactory.getLogger(SubscriptionService.class);
  private final SubscriptionTypeRepository subscriptionTypeRepository;
  private final SubscriptionTypeAssembler subscriptionTypeAssembler;
  private final SubscriptionAssembler subscriptionAssembler;
  private final PaymentService paymentService;

  public SubscriptionService(SubscriptionTypeRepository subscriptionTypeRepository,
      SubscriptionTypeAssembler subscriptionTypeAssembler,
      SubscriptionAssembler subscriptionAssembler,
      PaymentService paymentService) {
    this.subscriptionTypeRepository = subscriptionTypeRepository;
    this.subscriptionTypeAssembler = subscriptionTypeAssembler;
    this.subscriptionAssembler = subscriptionAssembler;
    this.paymentService = paymentService;
  }

  public List<SubscriptionTypeDto> findAllSubscriptionType() {
    LOGGER.info("Get all subscriptions Types");
    List<SubscriptionType> subscriptionTypes = subscriptionTypeRepository.findAll();
    return subscriptionTypes.stream().map(subscriptionTypeAssembler::create).toList();
  }

  public void addSubscription(SubscriptionDto subscriptionDto) {
    LOGGER.info("Add Subscription {}", subscriptionDto);
    SubscriptionType subscriptionType = subscriptionTypeRepository.findByName(
        subscriptionDto.subscriptionType());
    Subscription subscription = subscriptionAssembler.create(subscriptionType, subscriptionDto);

    paymentService.paySubscription(subscription);
  }

}
