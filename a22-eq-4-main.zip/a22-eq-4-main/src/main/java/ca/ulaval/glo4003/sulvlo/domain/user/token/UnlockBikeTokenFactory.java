package ca.ulaval.glo4003.sulvlo.domain.user.token;

import java.time.LocalDateTime;

public class UnlockBikeTokenFactory {

  public UnlockBikeToken create(String code) {
    return new UnlockBikeToken(code, expirationtoken());
  }

  private LocalDateTime expirationtoken() {
    return LocalDateTime.now().plusMinutes(1);
  }
}
