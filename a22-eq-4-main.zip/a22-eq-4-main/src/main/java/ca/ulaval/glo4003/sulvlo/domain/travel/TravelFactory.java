package ca.ulaval.glo4003.sulvlo.domain.travel;

import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import java.util.UUID;

public class TravelFactory {

  public Travel create(User user, Bike bike, Station unlockStation, Station returnStation) {
    return new Travel(UUID.randomUUID(), user.getId().toString(), unlockStation.getName(),
        bike.getUnlockDateTime(), bike.getReturnDateTime(), returnStation.getName(),
        bike.getUnlockDateTime().getMonth());
  }

}
