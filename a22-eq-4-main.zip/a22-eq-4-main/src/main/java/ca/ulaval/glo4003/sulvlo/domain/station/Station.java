package ca.ulaval.glo4003.sulvlo.domain.station;

import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.bike.EnergyLevel;
import ca.ulaval.glo4003.sulvlo.domain.bike.exception.BikeNotFoundException;
import ca.ulaval.glo4003.sulvlo.domain.station.exception.InvalidPlaceInStationException;
import ca.ulaval.glo4003.sulvlo.domain.station.exception.InvalidReturnInStationException;
import ca.ulaval.glo4003.sulvlo.domain.station.exception.NoMoreEmptySpaceInThisStationException;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Station {

  private static final double PERCENTAGE_GAIN_PER_MINUTE = 0.002;
  private final String location;
  private final String name;
  private final String code;
  private final int maxCapacity;
  private final List<Bike> availableBikes;
  private final List<Integer> emptyBikeLocations;
  private List<Bike> unlockedBikes = new ArrayList<>();
  private LocalDateTime currentDateTime = LocalDateTime.now();
  private int currentCapacity;

  public Station(String location, String name, String code, int currentCapacity, int maxCapacity,
      List<Bike> availableBikes, List<Integer> emptyBikeLocations) {
    this.location = location;
    this.name = name;
    this.code = code;
    this.currentCapacity = currentCapacity;
    this.maxCapacity = maxCapacity;
    this.availableBikes = availableBikes;
    this.emptyBikeLocations = emptyBikeLocations;
  }

  public LocalDateTime getCurrentDateTime() {
    return currentDateTime;
  }

  public void setCurrentDateTime(LocalDateTime currentDateTime) {
    this.currentDateTime = currentDateTime;
  }

  public String getLocation() {
    return location;
  }

  public String getName() {
    return name;
  }

  public String getCode() {
    return code;
  }

  public int getCurrentCapacity() {
    return currentCapacity;
  }

  public List<Bike> getAvailableBikes() {
    return availableBikes;
  }

  public List<Bike> getUnlockedBikes() {
    return unlockedBikes;
  }

  public int getNumberOfAvailableBikes() {
    return availableBikes.size();
  }

  public int getNumberOfTakenBikes() {
    return unlockedBikes.size();
  }

  public void setUnlockedBikes(List<Bike> unlockedBikes) {
    this.unlockedBikes = unlockedBikes;
  }

  public int getMaxCapacity() {
    return maxCapacity;
  }

  public List<Integer> getEmptyBikeLocations() {
    return emptyBikeLocations;
  }

  public List<Bike> findAvailableBikesByLocation(List<Integer> locations) {
    return locations.stream().map(this::findAvailableBikeByLocation).toList();
  }

  public void removeLoadedBikes(List<Integer> bikesLocations) {
    bikesLocations.forEach(location -> {
      Bike bike = findAvailableBikeByLocation(location);
      emptyBikeLocations.add(bike.getLocation());
      availableBikes.remove(bike);
      currentCapacity--;
    });
  }

  public Bike findAvailableBikeByLocation(int location) {
    for (Bike bike : availableBikes) {
      if (bike.getLocation() == location) {
        return bike;
      }
    }
    throw new BikeNotFoundException(location);
  }

  public Bike findUnlockedBikeByLocation(int location) {
    for (Bike bike : unlockedBikes) {
      if (bike.getLocation() == location) {
        return bike;
      }
    }
    throw new BikeNotFoundException(location);
  }

  public void rechargeBikes() {
    LocalDateTime newCurrentDateTime = LocalDateTime.now();
    LocalDateTime stationDateTime = currentDateTime;
    if (newCurrentDateTime.isAfter(stationDateTime)) {
      currentDateTime = newCurrentDateTime;
      for (Bike bike : availableBikes) {
        double newBikeEnergyLevel = calculNewEnergyLevel(newCurrentDateTime, stationDateTime, bike);
        bike.setEnergyLevel(new EnergyLevel(BigDecimal.valueOf(newBikeEnergyLevel)));
      }
    }
  }

  private double calculNewEnergyLevel(LocalDateTime newCurrentDateTime,
      LocalDateTime currentDateTime, Bike bike) {

    return bike.getEnergyLevel().getValue()
        + Duration.between(currentDateTime, newCurrentDateTime).toMinutes()
        * PERCENTAGE_GAIN_PER_MINUTE;
  }

  public void unlockBike(Bike bike) {
    bike.checkBikeEnergyLevelValidity();
    bike.setUnlockDateTime(LocalDateTime.now());
    bike.setToNotAvailable();
    unlockedBikes.add(bike);
    emptyBikeLocations.add(bike.getLocation());
    availableBikes.remove(bike);
    currentCapacity--;
  }

  public void returnBikeInSameStation(Bike bike, int returnLocation) {
    returnBikeProcess(bike, returnLocation);
    unlockedBikes.remove(bike);
  }

  public void returnBikeInDiffStation(Bike bike, Station unlockStation, int returnLocation) {
    returnBikeProcess(bike, returnLocation);
    unlockStation.getUnlockedBikes().remove(bike);
  }

  private void returnBikeProcess(Bike bike, int returnLocation) {
    checkTravelLimits(bike);
    checkStationCapacity();
    checkReturnLocationValidity(returnLocation);
    bike.setLocation(returnLocation);
    bike.setReturnDateTime(LocalDateTime.now());
    bike.calculateEnergyLevelAfterReturn();
    bike.setToAvailable();
    availableBikes.add(bike);
    currentCapacity++;
    emptyBikeLocations.remove(Integer.valueOf(bike.getLocation()));
  }

  private void checkTravelLimits(Bike bike) {
    if (bike.IsUnlockedByNormalUser()) {
      bike.checkTravelDurationForNormalUsers();
    } else {
      bike.checkTravelDurationForEmployees();
    }
  }

  private void checkStationCapacity() {
    if (currentCapacity == maxCapacity) {
      throw new NoMoreEmptySpaceInThisStationException(code);
    }
  }

  private void checkReturnLocationValidity(int returnLocation) {
    if (!isReturnLocationEmpty(returnLocation)) {
      throw new InvalidReturnInStationException(code);
    }
  }

  private boolean isReturnLocationEmpty(int returnLocation) {
    return emptyBikeLocations.contains(returnLocation);
  }

  public void placeBike(int toStationBikeLocation, Bike loadedBike) {
    checkStationCapacity();
    if (emptyBikeLocations.contains(toStationBikeLocation)) {
      availableBikes.add(loadedBike);
      availableBikes.stream().filter(bike -> bike.equals(loadedBike)).toList().get(0)
          .setLocation(toStationBikeLocation);
      emptyBikeLocations.remove(Integer.valueOf(toStationBikeLocation));
      currentCapacity++;
    } else {
      throw new InvalidPlaceInStationException(code);
    }
  }
}
