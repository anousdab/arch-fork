package ca.ulaval.glo4003.sulvlo.domain.travel;

import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelDto;
import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelHistorySummaryDTO;
import ca.ulaval.glo4003.sulvlo.domain.travel.exception.InvalidUserIdException;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryFactory;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistorySummary;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class TravelService {

  private final TravelRepository travelRepository;
  private final TravelAssembler travelAssembler;
  private final TravelHistoryAssembler travelHistoryAssembler;
  private final TravelHistoryFactory travelHistoryFactory;

  public TravelService(TravelRepository travelRepository,
      TravelAssembler travelAssembler,
      TravelHistoryAssembler travelHistoryAssembler, TravelHistoryFactory travelHistoryFactory) {
    this.travelAssembler = travelAssembler;
    this.travelRepository = travelRepository;
    this.travelHistoryAssembler = travelHistoryAssembler;
    this.travelHistoryFactory = travelHistoryFactory;
  }

  public List<TravelDto> getAllTravelsFilteredByMonth(String actualMonth, String user_id) {
    Month transferedMonth = Month.valueOf(actualMonth.toUpperCase());
    List<Travel> listOfTravels = travelRepository.getAllTravels();
    return listOfTravels.stream().filter(travel ->
        travel.month().equals(transferedMonth) && travel.user_id().equals(user_id))
        .map(travelAssembler::create).toList();
  }

  public List<TravelDto> getAllTravels() {
    List<Travel> listOfTravels = travelRepository.getAllTravels();
    return listOfTravels.stream().map(travelAssembler::create).toList();
  }

  public TravelDto getTravelById(String travelID) throws InvalidTravelIdException {
    UUID travelUUID = validateStringToUUID(travelID);

    Travel travel = travelRepository.getTravel(travelUUID);
    return travelAssembler.create(travel);
  }

  public TravelHistorySummaryDTO getTravelHistorySummary(String userId) {
    List<Travel> listOfTravels = travelRepository.getAllTravels().stream().filter(travel ->
        travel.user_id().equals(userId)).toList();

    if (listOfTravels.isEmpty()) {
      throw new InvalidUserIdException();
    }

    long totalTime = getTravelsTotalTime(listOfTravels);
    String favoriteStation = getFavoriteStation(listOfTravels);
    String totalTimeInMilliSecond = millisecondsToTime(totalTime);
    String averageTimeInMillisecond = millisecondsToTime(totalTime / listOfTravels.size());

    TravelHistorySummary getSummaryInformation = travelHistoryFactory.create(totalTimeInMilliSecond,
        averageTimeInMillisecond,
        listOfTravels.size(),
        favoriteStation);

    return travelHistoryAssembler.create(getSummaryInformation);
  }

  private long getTravelsTotalTime(List<Travel> list) {

    long total = 0;
    for (Travel travel : list) {
      LocalDateTime dateOne = travel.startTravelDate();
      LocalDateTime dateTwo = travel.endTravelDate();
      total += Duration.between(dateOne, dateTwo).toMillis();
    }
    return total;
  }

  private String millisecondsToTime(long milliseconds) {
    long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
    long seconds = TimeUnit.SECONDS.toSeconds(milliseconds);
    String secondsStr = Long.toString(seconds);
    String secs = (secondsStr.length() >= 2) ? secondsStr.substring(0, 2) : "0" + secondsStr;
    return minutes + ":" + secs;
  }


  private String getFavoriteStation(List<Travel> listOfTravels) {
    ArrayList<String> listOfStationsVisited = getAllStationsVisited(listOfTravels);
    return listOfStationsVisited.stream()
        .collect(Collectors.groupingBy(w -> w, Collectors.counting()))
        .entrySet()
        .stream()
        .max(Map.Entry.comparingByValue())
        .get()
        .getKey();
  }


  private ArrayList<String> getAllStationsVisited(List<Travel> listOfTravels) {
    ArrayList<String> listOfStationsVisited = new ArrayList<>();
    for (Travel travel : listOfTravels) {
      listOfStationsVisited.add(travel.stationStartTravel());
      listOfStationsVisited.add(travel.stationEndTravel());
    }
    return listOfStationsVisited;
  }

  private UUID validateStringToUUID(String id) throws InvalidTravelIdException {
    UUID uuid;
    try {
      uuid = UUID.fromString(id);
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new InvalidTravelIdException();
    }
    return uuid;
  }
}
