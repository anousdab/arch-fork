package ca.ulaval.glo4003.sulvlo.domain.subscription;

import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardInformation;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionType;
import ca.ulaval.glo4003.sulvlo.domain.util.semester.Semester;

public record Subscription(
    SubscriptionType subscriptionType,
    String email,
    CreditCardInformation creditCard,
    Semester semester,
    boolean savePayment,
    boolean immediatePayment

) {

  public int subscriptionTypePrice() {
    return subscriptionType.price();
  }

  @Override
  public String toString() {
    return "Subscription{" +
        "subscriptionType=" + subscriptionType +
        ", email='" + email + '\'' +
        ", creditCard=" + creditCard +
        ", semester=" + semester +
        '}';
  }
}
