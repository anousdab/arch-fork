package ca.ulaval.glo4003.sulvlo.api.truck.validation;

import ca.ulaval.glo4003.sulvlo.api.truck.dto.FindTrucksRequest;

public class FindTrucksRequestValidator {

  private final CommonTruckRequestsValidators commonTruckRequestsValidators;

  public FindTrucksRequestValidator(CommonTruckRequestsValidators commonTruckRequestsValidators) {
    this.commonTruckRequestsValidators = commonTruckRequestsValidators;
  }

  public void validate(FindTrucksRequest findTrucksRequest) {
    commonTruckRequestsValidators.commonStationRequestsValidators().validateUserIdul(
        findTrucksRequest.userIdul());
  }
}
