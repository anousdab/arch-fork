package ca.ulaval.glo4003.sulvlo.domain.payment.cron;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;

import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;

public class SchedulePaymentJob {
    private final PaymentService paymentService;

    public SchedulePaymentJob(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    public void start() throws SchedulerException {
        initializeSendBill();
        initializePayMonthly();
        initializeBlockAccount();
    }

    void initializeSendBill() throws SchedulerException {
        JobDetail job = JobBuilder.newJob(SendBillJob.class).build();
        job.getJobDataMap().put("paymentService", paymentService);
        Trigger trigger = TriggerBuilder
                .newTrigger()
                .withSchedule(
                        CronScheduleBuilder.cronSchedule("0 0 12 L * ?"))
                .build();

        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(job, trigger);
    }

    void initializePayMonthly() throws SchedulerException {
        JobDetail job = JobBuilder.newJob(PayMonthlyJob.class).build();
        job.getJobDataMap().put("paymentService", paymentService);
        Trigger trigger = TriggerBuilder
                .newTrigger()
                .withSchedule(
                        CronScheduleBuilder.cronSchedule("0 30 12 L * ?"))
                .build();
        // CronScheduleBuilder.cronSchedule("0 0 12 L * ?"))

        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(job, trigger);
    }

    void initializeBlockAccount() throws SchedulerException {
        JobDetail job = JobBuilder.newJob(BlockAccountJob.class).build();
        job.getJobDataMap().put("paymentService", paymentService);
        Trigger trigger = TriggerBuilder
                .newTrigger()
                .withSchedule(
                        CronScheduleBuilder.cronSchedule("0 0 12 15 * ?"))

                .build();
        // CronScheduleBuilder.cronSchedule("0 15 10 15 * ?"))

        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(job, trigger);
    }

}
