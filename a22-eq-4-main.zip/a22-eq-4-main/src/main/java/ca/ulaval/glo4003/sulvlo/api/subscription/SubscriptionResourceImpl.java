package ca.ulaval.glo4003.sulvlo.api.subscription;

import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.subscription.dto.SubscriptionDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionService;
import jakarta.ws.rs.core.Response;

public class SubscriptionResourceImpl implements SubscriptionResource {

  SubscriptionService subscriptionService;
  public static final String SUCCESSFULLY_SUSBCRIBED = "You have been successfully subscribed";

  private final ValidatorMediator validator = new ValidatorMediator();
  private final SuccessfulResponse successfulResponse;

  public SubscriptionResourceImpl(SubscriptionService subscriptionService,
      SuccessfulResponse successfulResponse) {
    this.subscriptionService = subscriptionService;
    this.successfulResponse = successfulResponse;
  }

  @Override
  public Response addSubscription(SubscriptionDto subscriptionDto) {
    validator.validSubscription(subscriptionDto);
    validator.validCreditCard(subscriptionDto);

    subscriptionService.addSubscription(subscriptionDto);

    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(SUCCESSFULLY_SUSBCRIBED).toString()).build();
  }

  @Override
  public Response getSubscriptions() {
    return Response.status(Response.Status.OK).entity(subscriptionService.findAllSubscriptionType())
        .build();
  }
}
