package ca.ulaval.glo4003.sulvlo.domain.bike;

public enum BikeStatus {
  AVAILABLE, IN_TRANSIT, NOT_AVAILABLE
}
