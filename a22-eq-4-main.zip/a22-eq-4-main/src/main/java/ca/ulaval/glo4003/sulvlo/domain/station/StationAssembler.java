package ca.ulaval.glo4003.sulvlo.domain.station;

import ca.ulaval.glo4003.sulvlo.api.station.dto.StationDto;
import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.bike.BikeAssembler;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StationAssembler {

  private final BikeAssembler bikeAssembler;

  public StationAssembler() {
    this.bikeAssembler = new BikeAssembler();
  }

  public StationDto createStationDto(Station station) {
    return new StationDto(station.getCurrentDateTime()
        .format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM)),
        station.getLocation(),
        station.getName(),
        station.getCode(),
        station.getCurrentCapacity(),
        sortEmptyLocationList(station.getEmptyBikeLocations()),
        sortBikeList(station.getAvailableBikes()).stream()
        .map(bike -> bikeAssembler.createBikeDto(bike)).toList());
  }

  private List<Integer> sortEmptyLocationList(List<Integer> emptyLocationList) {
    Collections.sort(emptyLocationList);
    return emptyLocationList;
  }

  private List<Bike> sortBikeList(List<Bike> bikeList) {
    return bikeList.stream().sorted(Comparator.comparing(Bike::getLocation))
        .collect(Collectors.toList());
  }

}
