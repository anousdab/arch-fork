package ca.ulaval.glo4003.sulvlo.infrastructure.truck;

import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.station.exception.StationNotFoundException;
import ca.ulaval.glo4003.sulvlo.domain.truck.Truck;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckId;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckRepository;
import jakarta.ws.rs.NotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TruckRepositoryInMemory implements TruckRepository {

  private final TruckDataFactory truckDataFactory;

  private Map<TruckId, Truck> trucksHashMap = new HashMap<>();

  public TruckRepositoryInMemory(TruckDataFactory truckDataFactory) {
    this.truckDataFactory = truckDataFactory;
    List<Truck> trucks = this.truckDataFactory.createMockData();
    trucks.stream().forEach(truck -> save(truck));
  }

  @Override
  public List<Truck> findAll() {
    return trucksHashMap.values().stream().toList();
  }

  @Override
  public Truck findById(TruckId truckId) {
    Truck truck = trucksHashMap.get(truckId);
    if (truck != null) {
      return truck;
    }
    throw new NotFoundException("Truck Not found");
  }

  @Override
  public void save(Truck truck) {
    trucksHashMap.put(truck.getTruckId(), truck);
  }
}
