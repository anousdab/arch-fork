package ca.ulaval.glo4003.sulvlo.domain.payment.cron;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;

import org.quartz.JobDataMap;

public class SendBillJob implements Job {
    @Override
    public void execute(JobExecutionContext context)
            throws JobExecutionException {
        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        PaymentService paymentService = (PaymentService) dataMap.get("paymentService");
        paymentService.sendBillUsers();
    }

}
