package ca.ulaval.glo4003.sulvlo.domain.travel;

import ca.ulaval.glo4003.sulvlo.infrastructure.travel.exception.InvalidTravelIdException;
import java.util.List;
import java.util.UUID;

public interface TravelRepository {

  void save(Travel travel);

  List<Travel> getAllTravels();

  Travel getTravel(UUID ID) throws InvalidTravelIdException;

  int getTravelListSize();

}
