package ca.ulaval.glo4003.sulvlo.domain.payment;

import ca.ulaval.glo4003.sulvlo.api.payment.dto.AutomaticBillingDto;
import ca.ulaval.glo4003.sulvlo.api.payment.dto.CreditCardDto;
import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardAssembler;
import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardInformation;
import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;
import ca.ulaval.glo4003.sulvlo.domain.user.exception.InvalidActivationTokenException;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import java.math.BigDecimal;

public class PaymentService {

  private static final String SUBJECT = "Facture paiement SULVLO";

  private final UserRepository userRepository;
  private final CreditCardAssembler creditCardAssembler;
  private final PaymentDispatcher paymentDispatcher;
  private final EmailSender emailSender;

  public PaymentService(UserRepository userRepository, EmailSender emailSender) {
    this.userRepository = userRepository;
    this.emailSender = emailSender;
    this.creditCardAssembler = new CreditCardAssembler();
    this.paymentDispatcher = new PaymentDispatcher();
  }

  public void sendBillUsers() {
    for (User user : userRepository.getUsersList()) {
      BankAccount bankAccount = user.getBankAccount();
      if (!bankAccount.hasExtraFees() && !bankAccount.hasDebt()) {
        continue;
      }
      emailSender.sendUserBill(user.getEmail(), bankAccount);
    }
  }

  public void automaticPayExtraFeesUsers() {
    for (User user : userRepository.getUsersList()) {
      if (!user.getBankAccount().hasAutomaticBilling()) {
        continue;
      }
      payExtraFees(user.getIdul());
      user.getBankAccount().feesBecomeDebt();
      userRepository.update(user);
    }
  }

  public void blockUserAccountNotPaidBill() {
    for (User user : userRepository.getUsersList()) {
      BankAccount bankAccount = user.getBankAccount();
      if (bankAccount.hasDebt()) {
        continue;
      }
      user.blockAccount();
    }
  }

  public void payExtraFees(String idul) {
    User user = userRepository.getByIdul(idul);

    if (!user.getBankAccount().hasExtraFees()) {
      return;
    }
    paymentDispatcher.payExtraFees(user);
    userRepository.update(user);
  }

  public void payDebt(String idul) {
    User user = userRepository.getByIdul(idul);

    if (!user.getBankAccount().hasDebt()) {
      return;
    }
    paymentDispatcher.payDebt(user);
    userRepository.update(user);
  }

  public void payDirectly(String idul, BigDecimal amount) {
    User user = userRepository.getByIdul(idul);

    paymentDispatcher.directPayment(user, amount);
    userRepository.update(user);
  }

  public void addAutomaticBiling(String idul, AutomaticBillingDto automaticBillingDto) {
    User user = userRepository.getByIdul(idul);
    BankAccount bankAccount = user.getBankAccount();

    bankAccount.setAutomaticBilling(automaticBillingDto.automaticBilling());
    user.setBankAccount(bankAccount);
    userRepository.update(user);
  }

  public void saveCreditCard(String idul, CreditCardDto creditCardDto) {
    User user = userRepository.getByIdul(idul);
    BankAccount bankAccount = user.getBankAccount();
    CreditCardInformation creditCard = creditCardAssembler.create(creditCardDto);

    bankAccount.saveCreditCard(creditCard);
    user.setBankAccount(bankAccount);
    userRepository.update(user);
  }

  public void paySubscription(Subscription subscription) {

    User user = userRepository.getByEmail(subscription.email());

    if (!user.isAccountVerified()) {
      throw new InvalidActivationTokenException();
    }
    paymentDispatcher.subscriptionPayment(user, subscription);
    userRepository.update(user);
    emailSender.send(user.getEmail(), subscription.toString(), SUBJECT);
  }

}
