package ca.ulaval.glo4003.sulvlo.domain.util.email;

import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;

public interface EmailSender {
  void send(String receiverEmail, String body, String subject);
  public void sendUserBill(String email, BankAccount bankAccount);
}
