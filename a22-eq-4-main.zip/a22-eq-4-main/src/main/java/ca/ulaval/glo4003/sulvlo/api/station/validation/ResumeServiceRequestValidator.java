package ca.ulaval.glo4003.sulvlo.api.station.validation;

import ca.ulaval.glo4003.sulvlo.api.station.dto.StopMaintenanceRequest;

public class ResumeServiceRequestValidator {

  private final CommonStationRequestsValidators commonStationRequestsValidators;

  public ResumeServiceRequestValidator(
      CommonStationRequestsValidators commonStationRequestsValidators) {
    this.commonStationRequestsValidators = commonStationRequestsValidators;
  }

  public void validate(StopMaintenanceRequest stopMaintenanceRequest) {
    commonStationRequestsValidators.validateStationCode(stopMaintenanceRequest.stationCode());
    commonStationRequestsValidators.validateUserIdul(stopMaintenanceRequest.userIdul());
  }

}
