package ca.ulaval.glo4003.sulvlo.domain.user.token;

import ca.ulaval.glo4003.sulvlo.domain.user.exception.UniqueCodeTokenException;
import java.time.LocalDateTime;

public class UnlockBikeToken {

  public static final UnlockBikeToken NULL = new UnlockBikeToken(null);

  private LocalDateTime finishDate;
  private String code;

  public UnlockBikeToken(String code, LocalDateTime finishDate) {
    this.code = code;
    this.finishDate = finishDate;
  }

  public UnlockBikeToken(String code) {
    this.code = code;
  }

  public boolean isNull() {
    return this == NULL;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public boolean validateTokenIsActif(String validationToken, LocalDateTime date) {
    if (this.finishDate.isBefore(date) || !validationToken.equals(this.code)) {
      throw new UniqueCodeTokenException();
    }
    return true;
  }
}
