package ca.ulaval.glo4003.sulvlo.api.user.dto;

public interface PasswordDto {

  String password();

}
