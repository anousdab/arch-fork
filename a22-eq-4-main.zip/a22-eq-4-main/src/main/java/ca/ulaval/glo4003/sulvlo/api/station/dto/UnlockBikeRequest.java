package ca.ulaval.glo4003.sulvlo.api.station.dto;

public class UnlockBikeRequest {

  private String userCode;
  private String stationCode;
  private String bikeLocation;

  private UnlockBikeRequest(String userCode, String stationCode, String bikeLocation) {
    this.userCode = userCode;
    this.stationCode = stationCode;
    this.bikeLocation = bikeLocation;
  }

  public UnlockBikeRequest() {}

  public UnlockBikeRequest create(String userCode, String stationCode, String bikeLocation) {
    return new UnlockBikeRequest(userCode, stationCode, bikeLocation);
  }

  public String userCode() {
    return userCode;
  }

  public String stationCode() {
    return stationCode;
  }

  public String bikeLocation() {
    return bikeLocation;
  }
}
