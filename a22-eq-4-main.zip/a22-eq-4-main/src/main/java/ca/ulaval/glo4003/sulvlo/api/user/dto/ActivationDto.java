package ca.ulaval.glo4003.sulvlo.api.user.dto;

public record ActivationDto(
    String email
) {}
