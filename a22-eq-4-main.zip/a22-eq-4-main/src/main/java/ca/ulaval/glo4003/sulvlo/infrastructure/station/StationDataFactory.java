package ca.ulaval.glo4003.sulvlo.infrastructure.station;

import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import java.util.List;

public interface StationDataFactory {
  List<Station> createMockData();
}
