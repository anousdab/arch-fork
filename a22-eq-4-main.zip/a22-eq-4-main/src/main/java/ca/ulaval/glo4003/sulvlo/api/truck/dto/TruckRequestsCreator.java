package ca.ulaval.glo4003.sulvlo.api.truck.dto;


public class TruckRequestsCreator {
  private final FindTrucksRequest findTrucksRequest;
  private final LoadBikesRequest loadBikesRequest;
  private final UnloadBikesRequest unloadBikesRequest;


  public TruckRequestsCreator(FindTrucksRequest findTrucksRequest, LoadBikesRequest loadBikesRequest,
      UnloadBikesRequest unloadBikesRequest) {
    this.findTrucksRequest = findTrucksRequest;
    this.loadBikesRequest = loadBikesRequest;
    this.unloadBikesRequest = unloadBikesRequest;
  }

  public FindTrucksRequest createFindTrucksRequest(String userIdul) {
    return findTrucksRequest.create(userIdul);
  }

  public LoadBikesRequest createLoadBikesDtoRequest(String userIdul, String truckId,
      LoadBikesDto loadBikesDto) {
    return loadBikesRequest.create(userIdul, truckId, loadBikesDto);
  }

  public UnloadBikesRequest createUnloadBikesRequest(String userIdul, String truckId,
      UnloadBikesDto unloadBikesDto) {
    return unloadBikesRequest.create(userIdul, truckId, unloadBikesDto);
  }

}
