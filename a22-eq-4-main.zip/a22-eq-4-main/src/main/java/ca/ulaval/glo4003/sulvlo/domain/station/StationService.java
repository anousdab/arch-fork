package ca.ulaval.glo4003.sulvlo.domain.station;

import ca.ulaval.glo4003.sulvlo.api.station.dto.BikesAvailabilitiesDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StartMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationDto;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StopMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;
import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.bike.BikesAvailabilitiesAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.Travel;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelFactory;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserRepository;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StationService {
  private static final Logger LOGGER = LoggerFactory.getLogger(StationService.class);
  public static final String MANAGER_NOTIFICATION_EMAIL_SUBJECT = "Bike availabilities count for SULVLO";
  public static final String MANAGER_NOTIFICATION_EMAIL_BODY= "The avalaible bike count is currently null.";
  private static final String MANAGER_EMAIL = "ROTHSCHILD@nospam.today";

  private final UserRepository userRepository;
  private final TravelRepository travelRepository;
  private final StationRepository stationRepository;
  private final StationAssembler stationAssembler;
  private final BikesAvailabilitiesAssembler bikesAvailabilitiesAssembler;
  private final TravelFactory travelFactory;
  private final EmailSender emailSender;

  public StationService(UserRepository userRepository, TravelRepository travelRepository,
      StationRepository stationRepository, StationAssembler stationAssembler, BikesAvailabilitiesAssembler bikesAvailabilitiesAssembler,
      TravelFactory travelFactory, EmailSender emailSender) {
    this.userRepository = userRepository;
    this.travelRepository = travelRepository;
    this.stationRepository = stationRepository;
    this.stationAssembler = stationAssembler;
    this.bikesAvailabilitiesAssembler = bikesAvailabilitiesAssembler;
    this.emailSender = emailSender;
    this.travelFactory = travelFactory;
  }

  public List<StationDto> findAllAvailableStations() {
    LOGGER.info("Get all available stations");
    List<Station> stations = stationRepository.findAllAvailable();
    stations.forEach(Station::rechargeBikes);
    return stations.stream().map(stationAssembler::createStationDto).collect(Collectors.toList());
  }

  public List<StationDto> findAllUnderMaintenanceStations() {
    LOGGER.info("Get all under maintenance stations");
    List<Station> stations = stationRepository.findAllUnderMaintenance();
    return stations.stream().map(stationAssembler::createStationDto).collect(Collectors.toList());
  }

  public BikesAvailabilitiesDto findAllBikesAvailabilities() {
    LOGGER.info("Get all bikes availabilities");
    List<Station> stations = stationRepository.findAllStations();
    int numberOfAvailableBikes = stations.stream().mapToInt(Station::getNumberOfAvailableBikes).sum();
    int numberOfTakenBikes = stations.stream().mapToInt(Station::getNumberOfTakenBikes).sum();
    return bikesAvailabilitiesAssembler.create(numberOfAvailableBikes, numberOfTakenBikes);
  }

  public void unlockBike(UnlockBikeRequest unlockBikeRequest) {
    LOGGER.info("Unlock bike {}", unlockBikeRequest);
    User user = userRepository.getUserByUniqueCode(unlockBikeRequest.userCode());
    user.validateUnlockBikeToken(unlockBikeRequest.userCode());
    Station station = stationRepository.findAvailableByCode(unlockBikeRequest.stationCode());
    Bike bike = station.findAvailableBikeByLocation(toIntBikeLocation(unlockBikeRequest.bikeLocation()));
    bike.setCurrentUser(user);
    station.unlockBike(bike);
    stationRepository.saveAvailable(station);
    verifyCurrentBikesAvailabilities();
  }

  public void verifyCurrentBikesAvailabilities() {
    BikesAvailabilitiesDto bikesAvailabilitiesDto = findAllBikesAvailabilities();
    if(bikesAvailabilitiesDto.numberOfAvailableBikes() == 0) sendEmailNotification();
  }

  public void sendEmailNotification() {
    emailSender.send(MANAGER_EMAIL, MANAGER_NOTIFICATION_EMAIL_BODY, MANAGER_NOTIFICATION_EMAIL_SUBJECT);
  }
  public Travel returnBikeInDifferentStation(ReturnBikeRequest returnBikeRequest, Station unlockStation, Bike bike, User user){
    Travel travel;
    Station returnStation = stationRepository.findAvailableByCode(returnBikeRequest.returnStationCode());
    returnStation.returnBikeInDiffStation(bike, unlockStation, toIntBikeLocation(returnBikeRequest.returnBikeLocation()));
    travel = travelFactory.create(user, bike, unlockStation, returnStation);
    stationRepository.saveAvailable(returnStation);
     return travel;
  }

  public Travel returnBikeToSameStation(ReturnBikeRequest returnBikeRequest, Station unlockStation, Bike bike, User user){
    Travel travel;
    unlockStation.returnBikeInSameStation(bike, toIntBikeLocation(returnBikeRequest.returnBikeLocation()));
    travel = travelFactory.create(user, bike, unlockStation, unlockStation);
    stationRepository.saveAvailable(unlockStation);
    return travel;
  }

  public void returnBike(ReturnBikeRequest returnBikeRequest) {
    // TODO: separer cette fonctions en sous-fonctions
    LOGGER.info("Return bike {}", returnBikeRequest);
    Station unlockStation = stationRepository.findAvailableByCode(returnBikeRequest.unlockStationCode());
    Bike bike = unlockStation.findUnlockedBikeByLocation(toIntBikeLocation(returnBikeRequest.unlockBikeLocation()));
    User user = bike.getCurrentUser();
    Travel travel;

    if (!returnBikeRequest.unlockStationCode().equals(returnBikeRequest.returnStationCode())) {
      travel = returnBikeInDifferentStation(returnBikeRequest, unlockStation,bike, user);
    } else {
      travel = returnBikeToSameStation(returnBikeRequest,unlockStation, bike, user);
    }
    travelRepository.save(travel);
    bike.setCurrentUser(null);
  }

  public void startMaintenance(StartMaintenanceRequest startMaintenanceRequest) {
    LOGGER.info("Start maintenance");
    String stationCode = startMaintenanceRequest.stationCode();
    Station station = stationRepository.findAvailableByCode(stationCode);
    stationRepository.deleteAvailable(stationCode);
    stationRepository.saveUnderMaintenance(station);
  }

  public void endMaintenance(StopMaintenanceRequest stopMaintenanceRequest) {
    LOGGER.info("End maintenance");
    String stationCode = stopMaintenanceRequest.stationCode();
    Station station = stationRepository.findUnderMaintenanceByCode(stationCode);
    stationRepository.deleteUnderMaintenance(stationCode);
    stationRepository.saveAvailable(station);
  }

  private int toIntBikeLocation(String bikeLocation) {
    return Integer.parseInt(bikeLocation);
  }

}
