package ca.ulaval.glo4003.sulvlo.domain.station;

public enum StationStatus {
  AVAILABLE, UNDER_MAINTENANCE
}
