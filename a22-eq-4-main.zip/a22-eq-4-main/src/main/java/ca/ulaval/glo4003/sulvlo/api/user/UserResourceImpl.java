package ca.ulaval.glo4003.sulvlo.api.user;

import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.user.dto.ActivationDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RequestMaintenanceDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidatorMediator;
import ca.ulaval.glo4003.sulvlo.domain.user.UserService;
import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.core.SecurityContext;
import java.security.Principal;
import java.util.UUID;

public class UserResourceImpl implements UserResource {

  private static final String USER_CREATE_SUCCESS = "User successfully created.";
  private static final String USER_ACCOUNT_VERIFICATION = "User is successfully verified.";
  private static final String USER_BIKE_UNIQUE_CODE = "Unique code was successfully sent to your email.";
  private final ValidatorMediator validator = new ValidatorMediator();

  private final SuccessfulResponse successfulResponse;
  private final UserService userService;

  public UserResourceImpl(SuccessfulResponse successfulResponse, UserService userService) {
    this.successfulResponse = successfulResponse;
    this.userService = userService;
  }

  @Override
  public Response register(RegisterDto registerDTO) throws ClientErrorException {
    validator.validRegisterDTO(registerDTO);
    UUID userId = userService.register(registerDTO);
    return Response.status(Status.CREATED)
        .header("activationToken",Integer.toString(userId.toString().hashCode()))
        .entity(successfulResponse.create(USER_CREATE_SUCCESS).toString())
        .build();
  }

  @Override
  public Response login(LoginDto loginDTO) throws ClientErrorException {
    validator.validLoginDTO(loginDTO);
    return (Response.status(Status.OK)
        .entity(userService.login(loginDTO))
        .build());
  }


  @Override
  public Response requestMaintenance(RequestMaintenanceDto requestMaintenanceDto) {
    // TODO : Add validator of RequestMaintenanceDto
    // userValidator.validateRequestMaintenanceDto(requestMaintenanceDto);
    userService.sendMaintenanceRequest(requestMaintenanceDto);
    return (Response.status(Status.OK).build());
  }

  @Override
  public Response activation(String validationToken, ActivationDto activationDto) {
    userService.activateUser(validationToken, activationDto);
    return Response.status(Response.Status.OK)
        .entity(successfulResponse.create(USER_ACCOUNT_VERIFICATION).toString())
        .build();
  }

  @Override
  public Response uniqueCode(ActivationDto activationDto) {
    userService.sendUniqueCodeToUnlockBike(activationDto.email());
    return Response.status(Status.OK)
        .entity(successfulResponse.create(USER_BIKE_UNIQUE_CODE).toString())
        .build();
  }

  @Override
  public Response getProtectedRequest(@Context SecurityContext securityContext) {
    Principal principal = securityContext.getUserPrincipal();
    return Response.status(Status.ACCEPTED)
        .entity(principal)
        .build();
  }
}
