package ca.ulaval.glo4003.sulvlo.infrastructure.user;


import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.UserRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.UserType;
import ca.ulaval.glo4003.sulvlo.infrastructure.user.exception.UserAlreadyExistsException;
import jakarta.ws.rs.NotAuthorizedException;
import jakarta.ws.rs.NotFoundException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserRepositoryInMemory implements UserRepository {

  private static final String USER_ALREADY_EXIST = "A user with the given email already exist.";
  private static final String USER_DOESNOT_EXIST = "User with the given email does not exist.";

  private final HashMap<String, User> listUser = new HashMap<>();

  public UserRepositoryInMemory() {
    UserDevDataFactory userDevDataFactory = new UserDevDataFactory();
    List<User> users = userDevDataFactory.createMockData();
    users.stream().forEach(user -> save(user));
  }

  @Override
  public void save(User user) {
    if (listUser.containsKey(user.getEmail())) {
      throw new UserAlreadyExistsException(USER_ALREADY_EXIST);
    }
    listUser.put(user.getEmail(), user);
  }

  @Override
  public User getByEmail(String email) {
    if (!listUser.containsKey(email)) {
      throw new NotAuthorizedException(USER_DOESNOT_EXIST);
    }
    return listUser.get(email);
  }


  @Override
  public List<User> getUsersByType(UserType userType) {
    return listUser.values().stream().filter(user -> user.getUserType().equals(userType)).toList();
  }

  @Override
  public User getByIdul(String idul) {
    for (User user : listUser.values()) {
      if (idul.equals(user.getIdul())) {
        return user;
      }
    }
    throw new NotFoundException("Idul does not exist");
  }
  @Override
  public User getUserByUniqueCode(String code) {
    for (User user : listUser.values()) {
      if (code.equals(user.getUnlockBikeToken().getCode())) {
        return user;
      }
    }
    throw new NotFoundException("Unique code does not exist");
  }
  @Override
  public List<String> getIdList() {
    return new ArrayList<String>(listUser.keySet());
  }

  @Override
  public List<User> getUsersList() {
    return new ArrayList<User>(listUser.values());
  }

  @Override
  public void update(User user) {
    listUser.put(user.getEmail(), user);
  }
}
