package ca.ulaval.glo4003.sulvlo.api.station.dto;

public class StationRequestsCreator {

  private final UnlockBikeRequest unlockBikeRequest;
  private final ReturnBikeRequest returnBikeRequest;
  private final StartMaintenanceRequest startMaintenanceRequest;
  private final StopMaintenanceRequest stopMaintenanceRequest;

  public StationRequestsCreator(
      UnlockBikeRequest unlockBikeRequest, ReturnBikeRequest returnBikeRequest,
      StartMaintenanceRequest startMaintenanceRequest,
      StopMaintenanceRequest stopMaintenanceRequest) {
    this.unlockBikeRequest = unlockBikeRequest;
    this.returnBikeRequest = returnBikeRequest;
    this.startMaintenanceRequest = startMaintenanceRequest;
    this.stopMaintenanceRequest = stopMaintenanceRequest;
  }

  public UnlockBikeRequest createUnlockBikeRequest(String userCode, String stationCode,
      String bikeLocation) {
    return unlockBikeRequest.create(userCode, stationCode, bikeLocation);
  }

  public ReturnBikeRequest createReturnBikeRequest(String unlockStationCode,
      String unlockBikeLocation, String returnStationCode, String returnBikeLocation) {
    return returnBikeRequest.create(unlockStationCode, unlockBikeLocation, returnStationCode,
        returnBikeLocation);
  }

  public StartMaintenanceRequest createStartMaintenanceRequest(String userIdul,
      String stationCode) {
    return startMaintenanceRequest.create(userIdul, stationCode);
  }

  public StopMaintenanceRequest createStopMaintenanceRequest(String userIdul, String stationCode) {
    return stopMaintenanceRequest.create(userIdul, stationCode);
  }
}
