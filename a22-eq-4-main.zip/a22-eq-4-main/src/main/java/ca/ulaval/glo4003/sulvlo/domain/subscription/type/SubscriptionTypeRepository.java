package ca.ulaval.glo4003.sulvlo.domain.subscription.type;


import java.util.List;

public interface SubscriptionTypeRepository {

  List<SubscriptionType> findAll();

  SubscriptionType findByName(String subscriptionType);

  void save(SubscriptionType subscriptionType);
}
