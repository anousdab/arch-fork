package ca.ulaval.glo4003.sulvlo.api.validation.Nodes.Register;

import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.validation.ValidationNode;

public class IdulValidation extends ValidationNode<RegisterDto> {

  @Override
  public boolean isValid(RegisterDto model) {
    if (model.idul() == null || model.idul().isBlank() || model.idul().length() > 10) {
      return false;
    }
    return validNext(model);
  }

}
