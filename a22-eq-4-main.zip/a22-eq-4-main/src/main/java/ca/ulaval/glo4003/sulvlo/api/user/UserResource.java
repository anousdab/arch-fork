package ca.ulaval.glo4003.sulvlo.api.user;

import ca.ulaval.glo4003.sulvlo.api.user.dto.ActivationDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.LoginDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RegisterDto;
import ca.ulaval.glo4003.sulvlo.api.user.dto.RequestMaintenanceDto;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import org.glassfish.jersey.process.internal.RequestScoped;

@RequestScoped
@Path("/api/users")
public interface UserResource {

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/register")
  @PermitAll
  Response register(RegisterDto info);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/login")
  @PermitAll
  Response login(LoginDto info);

  @GET
  @Path("/protected")
  @Produces(MediaType.APPLICATION_JSON)
  @RolesAllowed({"MANAGER"})
  Response getProtectedRequest(@Context SecurityContext securityContext);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/request-maintenance")
  @PermitAll
  Response requestMaintenance(RequestMaintenanceDto requestMaintenanceDto);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/activation")
  @PermitAll
  Response activation(@HeaderParam("activation-token") String validationToken,
      ActivationDto activationDto);

  @POST
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/unique-code")
  Response uniqueCode(ActivationDto activationDto);

}