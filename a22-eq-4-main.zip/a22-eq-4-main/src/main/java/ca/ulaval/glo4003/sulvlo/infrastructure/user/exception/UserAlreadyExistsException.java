package ca.ulaval.glo4003.sulvlo.infrastructure.user.exception;

import jakarta.ws.rs.ClientErrorException;
import jakarta.ws.rs.core.Response;

public class UserAlreadyExistsException extends ClientErrorException {

  public UserAlreadyExistsException(final String message) {
    super(message, Response.Status.CONFLICT);
  }

}
