package ca.ulaval.glo4003.sulvlo.domain.user.bank;

import com.google.common.base.Objects;

import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardInformation;

import java.math.BigDecimal;

public class BankAccount {

  private Balance debt;
  private Balance fees;
  private CreditCardInformation savedCreditCard;
  private boolean automaticBilling;

  public BankAccount() {
    this.debt = new Balance(BigDecimal.ZERO);
    this.fees = new Balance(BigDecimal.ZERO);
    this.savedCreditCard = null;
    this.automaticBilling = false;
  }

  public void saveCreditCard(CreditCardInformation creditCard) {
    this.savedCreditCard = creditCard;
  }

  public Balance getExtraFees() {
    return fees;
  }

  public Balance getDebt() {
    return debt;
  }

  public boolean hasExtraFees() {
    return fees.empty();
  }

  public boolean hasDebt() {
    return debt.empty();
  }

  public void feesBecomeDebt() {
    debt.add(fees.amount());
    fees = Balance.ZERO;
  }

  public CreditCardInformation getSavedCreditCard() {
    return savedCreditCard;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BankAccount that = (BankAccount) o;
    return Objects.equal(debt, that.debt)
        && Objects.equal(fees, that.fees)
        && Objects.equal(automaticBilling, that.automaticBilling)
        && Objects.equal(savedCreditCard, that.savedCreditCard);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(debt, savedCreditCard);
  }

  public void setAutomaticBilling(boolean automaticBilling) {
    this.automaticBilling = automaticBilling;
  }

  public boolean hasAutomaticBilling() {
    return automaticBilling;
  }
}
