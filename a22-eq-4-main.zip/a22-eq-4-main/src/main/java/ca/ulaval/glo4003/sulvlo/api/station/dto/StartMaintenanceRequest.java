package ca.ulaval.glo4003.sulvlo.api.station.dto;

public class StartMaintenanceRequest {

  private String userIdul;
  private String stationCode;

  private StartMaintenanceRequest(String userIdul, String stationCode) {
    this.userIdul = userIdul;
    this.stationCode = stationCode;
  }

  public StartMaintenanceRequest() {
  }

  public StartMaintenanceRequest create(String userIdul, String stationCode) {
    return new StartMaintenanceRequest(userIdul, stationCode);
  }

  public String userIdul() {
    return userIdul;
  }

  public String stationCode() {
    return stationCode;
  }

}
