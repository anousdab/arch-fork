package ca.ulaval.glo4003.sulvlo.api.station.validation;

import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;

public class ReturnBikeRequestValidator {

  private final CommonStationRequestsValidators commonStationRequestsValidators;

  public ReturnBikeRequestValidator(CommonStationRequestsValidators commonStationRequestsValidators) {
    this.commonStationRequestsValidators = commonStationRequestsValidators;
  }

  public void validate(ReturnBikeRequest returnBikeRequest) {
    commonStationRequestsValidators.validateStationCode(returnBikeRequest.unlockStationCode());
    commonStationRequestsValidators.validateBikeLocation(returnBikeRequest.unlockBikeLocation());
    commonStationRequestsValidators.validateStationCode(returnBikeRequest.returnStationCode());
    commonStationRequestsValidators.validateBikeLocation(returnBikeRequest.returnBikeLocation());
  }
}
