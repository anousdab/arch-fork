package ca.ulaval.glo4003.sulvlo.domain.truck;

import ca.ulaval.glo4003.sulvlo.api.truck.dto.FindTrucksRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.TruckDto;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesRequest;
import ca.ulaval.glo4003.sulvlo.domain.bike.Bike;
import ca.ulaval.glo4003.sulvlo.domain.station.Station;
import ca.ulaval.glo4003.sulvlo.domain.station.StationRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TruckService {
  private static final Logger LOGGER = LoggerFactory.getLogger(TruckService.class);

  private final StationRepository stationRepository;
  private final TruckRepository truckRepository;
  private final TruckAssembler truckAssembler;

  public TruckService(StationRepository stationRepository,
      TruckRepository truckRepository, TruckAssembler truckAssembler) {
    this.stationRepository = stationRepository;
    this.truckRepository = truckRepository;
    this.truckAssembler = truckAssembler;
  }

  public List<TruckDto> findAllTrucks(FindTrucksRequest findTrucksRequest) {
    LOGGER.info("Get all available trucks");
    List<Truck> trucks = truckRepository.findAll();
    return trucks.stream().map(truckAssembler::createTruckDto).collect(Collectors.toList());
  }

  public void loadBikes(LoadBikesRequest loadBikesRequest) {
    LOGGER.info("Start loading bikes to truck");
    Truck truck = findTruckById(loadBikesRequest.truckId());
    Station station = findUnderMaintenanceStationByCode(loadBikesRequest.fromStationCode());
    truck.loadBikes(getBikesToBeLoaded(loadBikesRequest, station));
    station.removeLoadedBikes(toIntBikesLocations(loadBikesRequest.bikesLocations()));
    truckRepository.save(truck);
    stationRepository.saveUnderMaintenance(station);
  }

  private Truck findTruckById(String truckId) {
    return truckRepository.findById(TruckId.fromString(truckId));
  }

  private Station findUnderMaintenanceStationByCode(String code) {
    return stationRepository.findUnderMaintenanceByCode(code);
  }

  private List<Integer> toIntBikesLocations(List<String> bikesLocations) {
    return bikesLocations.stream().map(this::toIntBikeLocation).toList();
  }

  private int toIntBikeLocation(String bikeLocation) {
    return Integer.parseInt(bikeLocation);
  }

  private List<Bike> getBikesToBeLoaded(LoadBikesRequest loadBikesRequest, Station station) {
    return station.findAvailableBikesByLocation(
        toIntBikesLocations(loadBikesRequest.bikesLocations()));
  }

  public void unload(UnloadBikesRequest unloadBikesRequest) {
    LOGGER.info("Start placing bikes in station");
    Truck truck = findTruckById(unloadBikesRequest.truckId());
    unloadBikesRequest.unloadBikeDataList().forEach(unloadBikeData -> {
      Station station = findAvailableStationByCode(unloadBikeData.toStationCode());
      int inTruckBikeLocation = toIntBikeLocation(unloadBikeData.bikesLocations().get(0));
      int toStationBikeLocation = toIntBikeLocation(unloadBikeData.bikesLocations().get(1));
      truck.unload(station, inTruckBikeLocation, toStationBikeLocation);
      stationRepository.saveAvailable(station);
    });
    truckRepository.save(truck);
  }

  private Station findAvailableStationByCode(String code) {
    return stationRepository.findAvailableByCode(code);
  }

}
