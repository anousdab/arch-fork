package ca.ulaval.glo4003.sulvlo.api.truck.dto;


import java.util.List;

public class LoadBikesRequest {

  private String userIdul;
  private String truckId;
  private LoadBikesDto loadBikesDto;


  private LoadBikesRequest(String userIdul, String truckId, LoadBikesDto loadBikesDto) {
    this.userIdul = userIdul;
    this.truckId = truckId;
    this.loadBikesDto = loadBikesDto;
  }

  public LoadBikesRequest() {
  }

  public LoadBikesRequest create(String userIdul, String truckId, LoadBikesDto loadBikesDto) {
    return new LoadBikesRequest(userIdul, truckId, loadBikesDto);
  }

  public String userIdul() {
    return userIdul;
  }

  public String truckId() {
    return truckId;
  }

  public String fromStationCode() {
    return loadBikesDto.fromStationCode();
  }

  public List<String> bikesLocations() {
    return loadBikesDto.bikesLocations();
  }

}
