package ca.ulaval.glo4003.sulvlo.config;

public record FileStationDto(String location, String name, int capacity) {

}
