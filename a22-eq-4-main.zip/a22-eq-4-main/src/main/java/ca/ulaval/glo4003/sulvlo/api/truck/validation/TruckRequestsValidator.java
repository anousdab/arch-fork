package ca.ulaval.glo4003.sulvlo.api.truck.validation;

import ca.ulaval.glo4003.sulvlo.api.truck.dto.FindTrucksRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesRequest;

public class TruckRequestsValidator {

  private final FindTrucksRequestValidator findTrucksRequestValidator;
  private final LoadBikesRequestValidator loadBikesRequestValidator;
  private final UnloadBikesRequestValidator unloadBikesRequestValidator;

  public TruckRequestsValidator(FindTrucksRequestValidator findTrucksRequestValidator,
      LoadBikesRequestValidator loadBikesRequestValidator,
      UnloadBikesRequestValidator unloadBikesRequestValidator) {
    this.findTrucksRequestValidator = findTrucksRequestValidator;
    this.loadBikesRequestValidator = loadBikesRequestValidator;
    this.unloadBikesRequestValidator = unloadBikesRequestValidator;
  }

  public void validateFindTrucksRequest(FindTrucksRequest findTrucksRequest) {
    findTrucksRequestValidator.validate(findTrucksRequest);
  }

  public void validateLoadBikesRequest(LoadBikesRequest loadBikesRequest) {
    loadBikesRequestValidator.validate(loadBikesRequest);
  }

  public void validateUnloadBikesRequest(UnloadBikesRequest unloadBikesRequest) {
    unloadBikesRequestValidator.validate(unloadBikesRequest);
  }

}
