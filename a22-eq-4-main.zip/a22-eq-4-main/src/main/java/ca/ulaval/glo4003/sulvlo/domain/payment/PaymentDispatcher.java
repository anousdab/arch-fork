package ca.ulaval.glo4003.sulvlo.domain.payment;

import java.math.BigDecimal;

import ca.ulaval.glo4003.sulvlo.domain.payment.exception.PaymentNotAutorized;
import ca.ulaval.glo4003.sulvlo.domain.payment.information.PaymentInformation;
import ca.ulaval.glo4003.sulvlo.domain.subscription.Subscription;
import ca.ulaval.glo4003.sulvlo.domain.user.User;
import ca.ulaval.glo4003.sulvlo.domain.user.bank.Balance;
import ca.ulaval.glo4003.sulvlo.domain.user.bank.BankAccount;

public class PaymentDispatcher {

  private final PaymentProcessor paymentProcessor;

  public PaymentDispatcher() {
    this.paymentProcessor = new PaymentProcessor();
  }

  // Paie la totalité des frais supplémentaires
  public void payExtraFees(User user) {
    BankAccount bankAccount = user.getBankAccount();
    Balance extraFeesBalance = bankAccount.getExtraFees();
    PaymentInformation paymentInformation = new PaymentInformation(bankAccount.getSavedCreditCard(), extraFeesBalance.amount());

    process(extraFeesBalance, paymentInformation);
    user.setBankAccount(bankAccount);
  }

  // Paie la totalité des dettes
  public void payDebt(User user) {
    BankAccount bankAccount = user.getBankAccount();
    Balance debtBalance = bankAccount.getExtraFees();
    PaymentInformation paymentInformation = new PaymentInformation(bankAccount.getSavedCreditCard(), debtBalance.amount());

    if (process(debtBalance, paymentInformation))
      user.unblockAccount();
    else
      user.blockAccount();
    user.setBankAccount(bankAccount);
  }

  // Paie direct après un voyage
  public void directPayment(User user, BigDecimal amount) {
    BankAccount bankAccount = user.getBankAccount();
    Balance extraFeesBalance = bankAccount.getExtraFees();
    PaymentInformation paymentInformation = new PaymentInformation(bankAccount.getSavedCreditCard(), amount);

    extraFeesBalance.add(amount);
    process(extraFeesBalance, paymentInformation);
    user.setBankAccount(bankAccount);
  }

  // Paie la souscription
  public void subscriptionPayment(User user, Subscription subscription) {
    BankAccount bankAccount = user.getBankAccount();
    Balance extraFeesBalance = bankAccount.getExtraFees();
    BigDecimal amount = new BigDecimal(subscription.subscriptionTypePrice());

    if (subscription.savePayment()) {
      bankAccount.saveCreditCard(subscription.creditCard());
    }

    extraFeesBalance.add(amount);
    if (subscription.immediatePayment()) {
      PaymentInformation paymentInformation = new PaymentInformation(subscription.creditCard(), amount);

      if (process(extraFeesBalance, paymentInformation))
        user.unblockAccount();
      else
        user.blockAccount();
    }
    user.setBankAccount(bankAccount);
  }

  private boolean process(Balance balance, PaymentInformation information) {
    try {
      balance = paymentProcessor.processPayment(balance, information);
    } catch (PaymentNotAutorized ex) {
      return false;
    }
    return true;
  }

}
