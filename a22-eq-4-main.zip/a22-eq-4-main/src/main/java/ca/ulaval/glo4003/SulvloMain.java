package ca.ulaval.glo4003;

import ca.ulaval.glo4003.sulvlo.api.mapper.SuccessfulResponse;
import ca.ulaval.glo4003.sulvlo.api.payment.PaymentResource;
import ca.ulaval.glo4003.sulvlo.api.payment.PaymentResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.station.StationResource;
import ca.ulaval.glo4003.sulvlo.api.station.StationResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.station.dto.ReturnBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StartMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StationRequestsCreator;
import ca.ulaval.glo4003.sulvlo.api.station.dto.StopMaintenanceRequest;
import ca.ulaval.glo4003.sulvlo.api.station.dto.UnlockBikeRequest;
import ca.ulaval.glo4003.sulvlo.api.station.validation.CommonStationRequestsValidators;
import ca.ulaval.glo4003.sulvlo.api.station.validation.ResumeServiceRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.station.validation.ReturnBikeRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.station.validation.StartMaintenanceRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.station.validation.StationRequestsValidator;
import ca.ulaval.glo4003.sulvlo.api.station.validation.UnlockBikeRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.subscription.SubscriptionResource;
import ca.ulaval.glo4003.sulvlo.api.subscription.SubscriptionResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.travel.TravelResource;
import ca.ulaval.glo4003.sulvlo.api.travel.TravelResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.truck.TruckResource;
import ca.ulaval.glo4003.sulvlo.api.truck.TruckResourceImpl;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.FindTrucksRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.LoadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.TruckRequestsCreator;
import ca.ulaval.glo4003.sulvlo.api.truck.dto.UnloadBikesRequest;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.CommonTruckRequestsValidators;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.FindTrucksRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.LoadBikesRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.TruckRequestsValidator;
import ca.ulaval.glo4003.sulvlo.api.truck.validation.UnloadBikesRequestValidator;
import ca.ulaval.glo4003.sulvlo.api.user.UserResource;
import ca.ulaval.glo4003.sulvlo.api.user.UserResourceImpl;
import ca.ulaval.glo4003.sulvlo.auth.jwt.TokenAuthentificationService;
import ca.ulaval.glo4003.sulvlo.auth.jwt.filter.AuthenticationFilter;
import ca.ulaval.glo4003.sulvlo.auth.jwt.filter.AuthorizationFilter;
import ca.ulaval.glo4003.sulvlo.config.JsonFileReader;
import ca.ulaval.glo4003.sulvlo.domain.bike.BikesAvailabilitiesAssembler;
import ca.ulaval.glo4003.sulvlo.domain.payment.PaymentService;
import ca.ulaval.glo4003.sulvlo.domain.payment.cron.SchedulePaymentJob;
import ca.ulaval.glo4003.sulvlo.domain.payment.information.CreditCardAssembler;
import ca.ulaval.glo4003.sulvlo.domain.station.StationAssembler;
import ca.ulaval.glo4003.sulvlo.domain.station.StationRepository;
import ca.ulaval.glo4003.sulvlo.domain.station.StationService;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.SubscriptionService;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeAssembler;
import ca.ulaval.glo4003.sulvlo.domain.subscription.type.SubscriptionTypeRepository;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelFactory;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelRepository;
import ca.ulaval.glo4003.sulvlo.domain.travel.TravelService;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryAssembler;
import ca.ulaval.glo4003.sulvlo.domain.travel.history.TravelHistoryFactory;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckAssembler;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckRepository;
import ca.ulaval.glo4003.sulvlo.domain.truck.TruckService;
import ca.ulaval.glo4003.sulvlo.domain.user.UserRepository;
import ca.ulaval.glo4003.sulvlo.domain.user.UserService;
import ca.ulaval.glo4003.sulvlo.domain.util.email.EmailSender;
import ca.ulaval.glo4003.sulvlo.domain.util.semester.SemesterAssembler;
import ca.ulaval.glo4003.sulvlo.http.CORSResponseFilter;
import ca.ulaval.glo4003.sulvlo.infrastructure.station.StationDevDataFactory;
import ca.ulaval.glo4003.sulvlo.infrastructure.station.StationRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.subscription.type.SubscriptionTypeRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.travel.TravelLogRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.truck.TruckDevDataFactory;
import ca.ulaval.glo4003.sulvlo.infrastructure.truck.TruckRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.user.UserRepositoryInMemory;
import ca.ulaval.glo4003.sulvlo.infrastructure.util.email.EmailSenderImpl;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.filter.RolesAllowedDynamicFeature;
import org.glassfish.jersey.servlet.ServletContainer;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * RESTApi setup without using DI or spring
 */
@SuppressWarnings("all")
public class SulvloMain {

  private static final int PORT = 8080;
  public static final String BASE_URI = "http://localhost:8080/";
  private static final Logger LOGGER = LoggerFactory.getLogger(SulvloMain.class);

  private static EmailSender emailSender = new EmailSenderImpl();
  private static TravelFactory travelFactory = new TravelFactory();
  private static TravelHistoryFactory travelHistoryFactory = new TravelHistoryFactory();
  private static PaymentService paymentService;
  private static SuccessfulResponse successfulResponse = new SuccessfulResponse();
  private static CommonStationRequestsValidators commonStationRequestsValidators = new CommonStationRequestsValidators();
  private static CommonTruckRequestsValidators commonTruckRequestsValidators = new CommonTruckRequestsValidators(
      commonStationRequestsValidators);

  private Server server;

  private UserRepository userRepository;
  private StationRepository stationRepository;
  private TravelRepository travelRepository;
  private SubscriptionTypeRepository subscriptionTypeRepository;
  private TruckRepository truckRepository;
  private StationResource stationResource;
  private TruckResource truckResource;
  private TravelResource travelResource;
  private UserResource userResource;
  private SubscriptionResource subscriptionResource;
  private PaymentResource paymentResource;
  private static TokenAuthentificationService tokenAuthentificationService;

  public static void main(String[] args) throws SchedulerException {
    new SulvloMain().run();
  }

  public void run() throws SchedulerException {
    registerRepositories();
    registerEndpoints();

    server = new Server(PORT);

    ServletContextHandler contextHandler = new ServletContextHandler(server, "/");
    final ResourceConfig config = new ResourceConfig();
    registerResources(config);
    new SchedulePaymentJob(paymentService).start();

    ServletContainer container = new ServletContainer(config);
    ServletHolder servletHolder = new ServletHolder(container);
    contextHandler.addServlet(servletHolder, "/*");

    startServer();
  }

  private void registerRepositories() {
    stationRepository = new StationRepositoryInMemory(
        new StationDevDataFactory(new JsonFileReader()));
    travelRepository = new TravelLogRepositoryInMemory();
    truckRepository = new TruckRepositoryInMemory(new TruckDevDataFactory());
    userRepository = new UserRepositoryInMemory();
    subscriptionTypeRepository = new SubscriptionTypeRepositoryInMemory();
  }

  private void registerEndpoints() {
    paymentResource = createPaymentResource();
    stationResource = createStationResource();
    truckResource = createTruckResource();
    travelResource = createTravelResource();
    userResource = createUserResource();
    subscriptionResource = createSubscriptionResource();
  }

  private void registerResources(ResourceConfig resourceConfig) {
    LOGGER.info("Setup resources (API)");
    final AbstractBinder binder = new AbstractBinder() {
      @Override
      protected void configure() {
        bind(stationResource).to(StationResource.class);
        bind(truckResource).to(TruckResource.class);
        bind(travelResource).to(TravelResource.class);
        bind(userResource).to(UserResource.class);
        bind(subscriptionResource).to(SubscriptionResource.class);
        bind(paymentResource).to(PaymentResource.class);
      }
    };

    resourceConfig.register(binder);
    resourceConfig.register(new AuthenticationFilter(tokenAuthentificationService));
    resourceConfig.register(AuthorizationFilter.class);
    resourceConfig.register(new CORSResponseFilter());
    resourceConfig.register(RolesAllowedDynamicFeature.class);
    resourceConfig.packages("ca.ulaval.glo4003.sulvlo.api");
  }

  private StationResource createStationResource() {
    LOGGER.info("Setup station resource dependencies (DOMAIN + INFRASTRUCTURE)");

    StationAssembler stationAssembler = new StationAssembler();
    BikesAvailabilitiesAssembler bikesAvailabilitiesAssembler = new BikesAvailabilitiesAssembler();
    StationRequestsValidator stationRequestsValidator = new StationRequestsValidator(
        new UnlockBikeRequestValidator(commonStationRequestsValidators),
        new ReturnBikeRequestValidator(commonStationRequestsValidators),
        new StartMaintenanceRequestValidator(commonStationRequestsValidators),
        new ResumeServiceRequestValidator(commonStationRequestsValidators));
    StationRequestsCreator stationRequestsCreator = new StationRequestsCreator(
        new UnlockBikeRequest(), new ReturnBikeRequest(),
        new StartMaintenanceRequest(), new StopMaintenanceRequest());

    StationService stationService = new StationService(userRepository, travelRepository,
        stationRepository,
        stationAssembler,
        bikesAvailabilitiesAssembler, travelFactory, emailSender);
    return new StationResourceImpl(stationService, stationRequestsValidator, successfulResponse,
        stationRequestsCreator);
  }

  private TruckResource createTruckResource() {
    LOGGER.info("Setup truck resource dependencies (DOMAIN + INFRASTRUCTURE)");

    TruckAssembler truckAssembler = new TruckAssembler();
    TruckRequestsValidator truckRequestsValidator = new TruckRequestsValidator(
        new FindTrucksRequestValidator(commonTruckRequestsValidators),
        new LoadBikesRequestValidator(commonTruckRequestsValidators),
        new UnloadBikesRequestValidator(commonTruckRequestsValidators));
    TruckRequestsCreator truckRequestsCreator = new TruckRequestsCreator(new FindTrucksRequest(),
        new LoadBikesRequest(), new UnloadBikesRequest());

    TruckService truckService = new TruckService(stationRepository, truckRepository,
        truckAssembler);
    return new TruckResourceImpl(truckService, truckRequestsCreator, truckRequestsValidator,
        successfulResponse);
  }

  private TravelResource createTravelResource() {
    LOGGER.info("Setup travel resource dependencies (DOMAIN + INFRASTRUCTURE)");

    TravelAssembler travelAssembler = new TravelAssembler();
    TravelHistoryAssembler travelHistoryAssembler = new TravelHistoryAssembler();

    TravelService travelService = new TravelService(travelRepository, travelAssembler,
        travelHistoryAssembler,
        travelHistoryFactory);
    return new TravelResourceImpl(travelService);
  }

  private UserResource createUserResource() {
    LOGGER.info("Setup user resource dependencies (DOMAIN + INFRASTRUCTURE)");

    tokenAuthentificationService = new TokenAuthentificationService();

    UserService userService = new UserService(userRepository, stationRepository, emailSender);
    return new UserResourceImpl(successfulResponse, userService);
  }

  private SubscriptionResource createSubscriptionResource() {
    LOGGER.info("Setup subscription resource dependencies (DOMAIN + INFRASTRUCTURE)");

    SubscriptionTypeAssembler subscriptionTypeAssembler = new SubscriptionTypeAssembler();
    SubscriptionAssembler subscriptionAssembler = new SubscriptionAssembler(
        new CreditCardAssembler(), new SemesterAssembler());

    SubscriptionService subscriptionService = new SubscriptionService(subscriptionTypeRepository,
        subscriptionTypeAssembler,
        subscriptionAssembler, paymentService);
    return new SubscriptionResourceImpl(subscriptionService, successfulResponse);
  }

  private PaymentResource createPaymentResource() {
    LOGGER.info("Setup payment resource dependencies (DOMAIN + INFRASTRUCTURE)");

    paymentService = new PaymentService(userRepository, emailSender);

    return new PaymentResourceImpl(paymentService);
  }

  public void startServer() {
    try {
      LOGGER.info("Setup http server");
      server.start();
      LOGGER.info("Application started.%nStop the application using CTRL+C");
    } catch (Exception e) {
      stopServer();
    }
  }

  public void stopServer() {
    try {
      LOGGER.info("Shutting down the application...");
      server.stop();
      LOGGER.info("Done, exit.");
    } catch (Exception e) {
      LOGGER.error("Error shutting down the server", e);
      server.destroy();
    }
  }

}
