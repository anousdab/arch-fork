package ca.ulaval.glo4003.sulvlo.config;

import java.util.List;

public interface FileReader<T> {

  List<T> read(String path);
}
