package ca.ulaval.glo4003.sulvlo.domain.travel;

import ca.ulaval.glo4003.sulvlo.api.travel.dto.TravelDto;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TravelAssembler {

  private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(
      "yyyy-MM-dd HH:mm:ss");

  public TravelDto create(Travel travel) {
    return new TravelDto(travel.travelId().toString(), travel.user_id(),
        travel.stationStartTravel(), dateFormat(travel.startTravelDate()),
        dateFormat(travel.endTravelDate()), travel.stationEndTravel(), travel.month());
  }

  private String dateFormat(LocalDateTime date) {
    return date.format(formatter);
  }

}
