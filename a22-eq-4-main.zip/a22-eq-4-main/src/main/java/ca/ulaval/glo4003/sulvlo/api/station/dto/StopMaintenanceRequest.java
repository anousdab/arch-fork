package ca.ulaval.glo4003.sulvlo.api.station.dto;

public class StopMaintenanceRequest {

  private String userIdul;
  private String stationCode;

  private StopMaintenanceRequest(String userIdul, String stationCode) {
    this.userIdul = userIdul;
    this.stationCode = stationCode;
  }

  public StopMaintenanceRequest() {
  }

  public StopMaintenanceRequest create(String userIdul, String stationCode) {
    return new StopMaintenanceRequest(userIdul, stationCode);
  }

  public String userIdul() {
    return userIdul;
  }

  public String stationCode() {
    return stationCode;
  }

}
