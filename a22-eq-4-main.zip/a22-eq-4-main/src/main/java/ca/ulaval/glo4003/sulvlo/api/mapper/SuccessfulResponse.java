package ca.ulaval.glo4003.sulvlo.api.mapper;

public class SuccessfulResponse {

  private String message;

  private SuccessfulResponse(String message) {
    this.message = message;
  }

  public SuccessfulResponse() {
  }

  public SuccessfulResponse create(String message) {
    return new SuccessfulResponse(message);
  }

  @Override
  public String toString() {
    return String.format("{\n\t\"message\": \"%s\"\n}", message);
  }
}
