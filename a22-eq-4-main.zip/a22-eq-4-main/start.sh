mvn clean verify
java -jar target/application.jar
